

const { ApplicationCommandType, ApplicationCommandOptionType, EmbedBuilder, ButtonBuilder, ActionRowBuilder } = require('discord.js');
const config = require('../../config.json')
module.exports = {
    name: 'vipinvite',
    description: "Give an invite to a user",
    cooldown: 30000,
    options: [
        {
            name: "username",
            description: "The user to give invite.",
            required: true,
            type: ApplicationCommandOptionType.String
        },
    ],
    run: async (client, interaction) => {

        const username = interaction.options.getString("username");
        if (!username) {
            return interaction.reply({ content: `Please provide a valid username`, ephemeral: true })
        }

        if (!interaction.member.roles.cache.has('923697235852681287')) {
            return interaction.reply({ content: `You don't have permission to use this command!`, ephemeral: true })
        }


        const data = `{"token": "${process.env.KEY}", "username": "${username}"}`;

        const result = await fetch(process.env.BACKEND + '/bot/giveinv', {
            method: 'post',
            body: data,
            headers: { 'Content-Type': 'application/json' },

        }).then(res => res.json()).then(json => {

            if (json.error) return interaction.reply({ content: json.error, ephemeral: true });

            interaction.reply({ content: json.message, ephemeral: true });

        }).catch(err => {
            console.log(err);
            interaction.reply({ content: 'An error occurred while running this command!', ephemeral: true });
        });
    }
};