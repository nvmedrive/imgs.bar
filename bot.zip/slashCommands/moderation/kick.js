const { ApplicationCommandOptionType, EmbedBuilder } = require('discord.js');
const config = require('../../config.json'); //ok wtf i didnt update it?


module.exports = {
	name: 'kick',
	description: "kick a User",
    default_member_permissions: 'KickMembers',
    options: [
        {
            name: "user",
            description: "The user to kick.",
            required: true,
            type: ApplicationCommandOptionType.User
        },   
        {
            name: "reason",
            description: "reason for the kick",
            required: false,
            type: ApplicationCommandOptionType.String
        }
    ],
	cooldown: 3000,
	run: async (client, interaction) => {
        const target = interaction.options.getMember("user");
        const reason = interaction.options.getString('reason') || 'No Reason Provided.';

        if (target && target.id === `982998096722153483`) { //fuck u clynt
            return interaction.reply({ content: `YOU **CANNOT** KICK DADDY 😡😡😡`, ephemeral: true} )
        }

        //this check if the user tried to kick a bot
        if ((target.user.bot)) {       
            const embed = new EmbedBuilder()
            .setDescription(`I can't kick bots!`)
            .setColor(config.color)
            return interaction.reply({embeds: [embed]})
      }
        //this checks if the user tried to kick clynt
        if(target.id === interaction.guild.ownerId) {
            const embed = new EmbedBuilder()
            .setDescription("I can't kick the owner of the server!")
            .setColor(config.color)
            interaction.reply({embeds: [embed]});
            return;
        }
        //this checks if the user tried to kick the bot
        if(target.id === client.user.id) {
            const embed = new EmbedBuilder()
            .setDescription("I can't kick myself!")
            .setColor(config.color)
            interaction.reply({embeds: [embed]});
            return;
        }
        let ccclient = client.user;
        let cclient = interaction.guild.members.cache.find(
          (m) => m.id === `${ccclient.id}`
        );
        const crolle = cclient.roles.highest;
        let user = interaction.guild.members.cache.find(
          (m) => m.id === `${target.id}`
        );
        const urole = user.roles.highest;
        let aauthor = interaction.member;
        let author = interaction.guild.members.cache.find(
          (m) => m.id === `${aauthor.id}`
        );
        const arolle = author.roles.highest; //functions

        //this checks to see if the member has a higher role than the client
        if (urole.position > crolle.position) {
            const embed = new EmbedBuilder()
            .setDescription("I can't kick this user!")
            .setColor(config.color)
            interaction.reply({embeds: [embed]});
            return;
        }
        //this checks if the user is trying to kick himself
        if(target.id === interaction.user.id) {
            const embed = new EmbedBuilder()
            .setDescription("You can't kick yourself!")
            .setColor(config.color)
            interaction.reply({embeds: [embed]});
            return;
        }
        //this checks to see if the member has a higher role than the member who ran the command
        if (urole.position > arolle.position - 1) {
            const embed = new EmbedBuilder()
            .setDescription("I can't kick this user!")
            .setColor(config.color)
            interaction.reply({embeds: [embed]}); 
            return;
        }
         //checks if the user is kickable
        if(target.kickable) {
            const embed =  new EmbedBuilder()
            .setDescription(`You Have been Kicked from imgs.bar server with Reason: ${reason}!`)
            .setColor(config.color)
            .setFooter({text: `imgs.bar`})
            target.send({embeds: [embed]}).catch(async (err) => {
                console.log(err)
                return await interaction.editReply({content: `DM ERROR | Error, i can't send the 'You have been Kicked..' DM`})
            }).then(() => {
              target.kick({reason});
              const embed = new EmbedBuilder()
              .setDescription(`${target.user.tag} has been Kicked ✈\nReason: ${reason}`)
              .setColor(config.color)
              .setFooter({text: `imgs.bar`, iconURL: interaction.guild.iconURL()})
            return interaction.reply({embeds: [embed]})
        });
     } else {
       //if you cant kick the user throws error
       const embed = new EmbedBuilder()
       .setDescription(`I Can't Kick this User`)
       .setColor(config.color)
       .setFooter({text: `imgs.bar`, iconURL: interaction.guild.iconURL()})
       return interaction.reply({embeds: [embed]})
    }
}};