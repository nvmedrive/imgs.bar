const { ApplicationCommandOptionType, EmbedBuilder } = require('discord.js');
const config = require('../../config.json'); //ok wtf i didnt update it?

module.exports = {
	name: 'ban',
	description: "ban a User",
    default_member_permissions: 'BanMembers',
    options: [
        {
            name: "user",
            description: "The user to ban.",
            required: false,
            type: ApplicationCommandOptionType.User
        }, 
        {
            name: "id",
            description: "The id to ban.",
            required: false,
            type: ApplicationCommandOptionType.String //cant do integer because it says that is too large idk
        },    
        {
            name: "reason",
            description: "reason for the ban",
            required: false,
            type: ApplicationCommandOptionType.String
        }
    ],
	cooldown: 3000,
	run: async (client, interaction) => {
        const target = interaction.options.getMember("user");
        const userid = interaction.options.getString("id");
        const reason = interaction.options.getString('reason') || 'No Reason Provided.';
        if(!userid && !target) {
            return interaction.reply({content: `Please provide a valid id or username`, ephemeral: true})
        }

        if (userid && target) {
            return interaction.reply( {content: `You cannot select 2 options, please select only 1 😀`, ephemeral: true } )
        }
        

        if(userid) {
            const req = await fetch(`https://discordlookup.mesavirep.xyz/v1/user/${userid}`);
            const data = await req.json();
            const username = data?.tag ?? '';
            const bannedUsers = await interaction.guild.bans.fetch();
            if (bannedUsers.find((user) => user.user.id === userid)) {
                const embed = new EmbedBuilder()
                .setDescription(`This user is already banned!`)
                .setColor(config.color)
                .setFooter({text: "imgs.bar"})
            return interaction.reply({embeds: [embed]})
        }
            if(username === "undefined#undefined") {
                const embed = new EmbedBuilder()
                .setDescription(`Invalid ID or couldnt find the user`)
                .setColor(config.color)
                .setFooter({text: "imgs.bar"})
                return interaction.reply({embeds: [embed], ephemeral: true}); 
            } else {
            await interaction.guild.members.ban(userid).catch(() => {})
            const embed = new EmbedBuilder()
            .setDescription(`${target.user.tag} has been banned ✈\nReason: ${reason}`)
            .setColor(config.color)
            .setFooter({text: `imgs.bar`, iconURL: interaction.guild.iconURL()})
            return interaction.reply({embeds: [embed], ephemeral: true})
            }
        }

        if(target) {
        //this checks if the user tried to ban the bot
        if(target.id === client.user.id) {
            const embed = new EmbedBuilder()
            .setDescription("I can't ban myself!")
            .setColor(config.color)
            interaction.reply({embeds: [embed], ephemeral: true});
            return;
        }
            if ((target.user.bot)) {       
            const embed = new EmbedBuilder()
            .setDescription(`I can't ban bots!`)
            .setColor(config.color)
            return interaction.reply({embeds: [embed], ephemeral: true})
      }
        //this checks if the user tried to ban clynt
        if(target.id === interaction.guild.ownerId) {
            const embed = new EmbedBuilder()
            .setDescription("I can't ban the owner of the server!")
            .setColor(config.color)
            interaction.reply({embeds: [embed], ephemeral: true});
            return;
        }
        let ccclient = client.user;
        let cclient = interaction.guild.members.cache.find(
          (m) => m.id === `${ccclient.id}`
        );
        const crolle = cclient.roles.highest;
        let user = interaction.guild.members.cache.find(
          (m) => m.id === `${target.id}`
        );
        const urole = user.roles.highest;
        let aauthor = interaction.member;
        let author = interaction.guild.members.cache.find(
          (m) => m.id === `${aauthor.id}`
        );
        const arolle = author.roles.highest; //functions

        //this checks to see if the member has a higher role than the client
        if (urole.position > crolle.position) {
            const embed = new EmbedBuilder()
            .setDescription("I can't ban this user!")
            .setColor(config.color)
            interaction.reply({embeds: [embed], ephemeral: true});
            return;
        }
        //this checks if the user is trying to ban himself
        if(target.id === interaction.user.id) {
            const embed = new EmbedBuilder()
            .setDescription("You can't ban yourself!")
            .setColor(config.color)
            interaction.reply({embeds: [embed], ephemeral: true});
            return;
        }
        //this checks to see if the member has a higher role than the member who ran the command
        if (urole.position > arolle.position - 1) {
            const embed = new EmbedBuilder()
            .setDescription("I can't ban this user!")
            .setColor(config.color)
            interaction.reply({embeds: [embed], ephemeral: true});
            return;
        }
         //checks if the user is bannable
        if(target.bannable) {
            const embed =  new EmbedBuilder()
            .setDescription(`You Have been Banned from imgs.bar server with Reason: ${reason}!`)
            .setColor(config.color)
            .setFooter({text: `imgs.bar`})
            target.send({embeds: [embed]}).catch(async (err) => {
                console.log(err)
                return await interaction.editReply({content: `DM ERROR | Error, i can't send the 'You have been Banned..' DM`, ephemeral: true})
            }).then(() => {
              target.ban({reason});
              const embed = new EmbedBuilder()
              .setDescription(`${target.user.tag} has been banned ✈\nReason: ${reason}`)
              .setColor(config.color)
              .setFooter({text: `imgs.bar`, iconURL: interaction.guild.iconURL()})
            return interaction.reply({embeds: [embed], ephemeral: true})
        });
     } else {
       //if you cant ban the user throws error
       const embed = new EmbedBuilder()
       .setDescription(`I Can't Ban this User`)
       .setColor(config.color)
       .setFooter({text: `imgs.bar`, iconURL: interaction.guild.iconURL()})
       return interaction.reply({embeds: [embed], ephemeral: true})
     }
    }
}};