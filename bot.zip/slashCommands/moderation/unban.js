const { ApplicationCommandOptionType, EmbedBuilder } = require('discord.js');
const rgx = /^(?:<@!?)?(\d+)>?$/;
const config = require('../../config.json'); //ok wtf i didnt update it?


module.exports = {
	name: 'unban',
	description: "unban a user",
    default_member_permissions: 'BanMembers',
	cooldown: 3000,
    options: [
        {
            name: "userid",
            description: "the member id you want to unban",
            type: ApplicationCommandOptionType.String,
            required: true,
          },
    ],
	run: async (client, interaction) => {
        try {
        const id = (interaction.options.getString("userid"));
        if(!rgx.test(id)) {
            const embed = new EmbedBuilder()
            .setDescription(`Provide a Valid ID`)
            .setColor(config.color)
            .setFooter({text: "imgs.bar"})
		return interaction.reply({ embeds: [embed]})
        }
        const bannedUsers = await interaction.guild.bans.fetch();
        if (!bannedUsers.find((user) => user.user.id === id)) {
            const embed = new EmbedBuilder()
            .setDescription(`This user is not banned!`)
            .setColor(config.color)
            .setFooter({text: "imgs.bar"})
        return interaction.reply({embeds: [embed]})
    }
        await interaction.guild.members.unban(id)
        const embed = new EmbedBuilder()
		.setTitle('User unbanned!')
		.setDescription(`Successfully unbanned ${id}`)
		.setColor(config.color)
		.setTimestamp()
        .setFooter({text: `imgs.bar`, iconURL: interaction.guild.iconURL()})
		return interaction.reply({ embeds: [embed] })
	}
    catch (err) {
        console.log(err)
      }
    }
}