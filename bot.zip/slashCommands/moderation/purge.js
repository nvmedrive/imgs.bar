const { ApplicationCommandType, ApplicationCommandOptionType, EmbedBuilder, ButtonBuilder, ActionRowBuilder } = require('discord.js');
const config = require('../../config.json'); //ok wtf i didnt update it?


module.exports = {
	name: 'purge',
	description: "Deletes/Purges/Clears the channel messages!",
  default_member_permissions: 'ManageMessages',
	cooldown: 3000,
    options: [
        {
          name: "amount",
          description: "Amount of messages to purge.",
          type: ApplicationCommandOptionType.Integer,
          required: true,
        },
        {
          name: "member",
          description: "Purge this members messages.",
          type: ApplicationCommandOptionType.User,
          required: false,
        },
        {
          name: "word",
          description: "Purge the messages that has this word.",
          type: ApplicationCommandOptionType.String,
          required: false,
        },
      ],
	run: async (client, interaction) => {
        const amount = interaction.options.getInteger("amount");
        const member = interaction.options.getMember("member");
        const word = interaction.options.getString("word");
        if (amount < 1 || amount > 100) {
          const embed = new EmbedBuilder()
          .setDescription(`Please enter a number between 1 and 100.`)
          .setColor(config.color)
          .setFooter({text: "imgs.bar | note: that i cannot purge messages older than 14 days!"})
        interaction.reply({ embeds: [embed] }).then(
          setTimeout(() => {
              interaction.deleteReply()
          }, 5000)
      )
        }
        const messages = await interaction.channel.messages.fetch({
          limit: amount,
        });

        if (member) {
          const memberMessages = messages.filter((m) => m.author.id === member.id);
          const purged = await interaction.channel.bulkDelete(memberMessages, true);
    
          const embed = new EmbedBuilder()
            .setDescription(`Purged **${purged.size}** message(s) from **${member.user.tag}**`)
            .setColor(config.color)
            .setFooter({text: "imgs.bar | note: that i cannot purge messages older than 14 days!"})
          interaction.reply({ embeds: [embed] }).then(
            setTimeout(() => {
                interaction.deleteReply()
            }, 5000)
        )
        } else if (word) {
          const filteredWord = messages.filter((m) =>
            m.content.toLowerCase().includes(word)
          );
          const purged = await interaction.channel.bulkDelete(filteredWord, true);
    
          const embed = new EmbedBuilder()
            .setDescription(`Purged **${purged.size}** message(s) that contains **${word.toLowerCase()}**`)
            .setColor(config.color)
            .setFooter({text: "imgs.bar | note: that i cannot purge messages older than 14 days!"})
          interaction.reply({ embeds: [embed] }).then(
            setTimeout(() => {
                interaction.deleteReply()
            }, 5000)
        )
        } else if (member && word) {
          const memberMessages = messages.filter((m) => m.author.id === member.id && m.content.toLowerCase().includes(word));
          const purged = await interaction.channel.bulkDelete(memberMessages, true);
    
          const embed = new EmbedBuilder()
          .setDescription(`Purged **${purged.size}** message(s) from **${member.user.tag}** that contains **${word.toLowerCase()}**`)
          .setColor(config.color)
          .setFooter({text: "imgs.bar | note: that i cannot purge messages older than 14 days!"})
          interaction.reply({ embeds: [embed] }).then(
            setTimeout(() => {
                interaction.deleteReply()
            }, 5000)
        )
        } else {
          const purged = await interaction.channel.bulkDelete(messages, true);
          const embed = new EmbedBuilder()
            .setDescription(`Purged ${purged.size} message(s) in the channel`)
            .setColor(config.color)
            .setFooter({text: "imgs.bar | note: that i cannot purge messages older than 14 days!"})
          interaction.reply({ embeds: [embed] }).then(
            setTimeout(() => {
                interaction.deleteReply()
            }, 5000)
          )
	      }
      }
    }