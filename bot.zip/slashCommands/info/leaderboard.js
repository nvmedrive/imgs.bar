const { ApplicationCommandType, ApplicationCommandOptionType, EmbedBuilder, ButtonBuilder, ActionRowBuilder } = require('discord.js');
const config = require('../../config.json');
const fetch = require('node-fetch'); // Adding libs

module.exports = {
    name: 'leaderboard',
    description: "show top 10 uploaders on imgs.bar",
    cooldown: 3000,
    run: async (client, interaction) => {
        const req = await fetch(process.env.BACKEND + '/leaderboard');
        const data = await req.json();

        if (data?.error) {
            return interaction.reply({
                content: "Something went wrong!",
                ephemeral: true,
            });
        }

        let uploaders = "";
        for (let i = 0; i < data.data.length; i++) {
            const { count, username } = data.data[i];
            uploaders += `**${i + 1}.** ${username} - ${count} uploads\n`;
        }

        const embed = new EmbedBuilder()
            .setColor(config.color)
            .setTitle(`Leaderboard || imgs.bar`)
            .setThumbnail('https://imgs.bar/logo.png')
            .addFields(
                {
                    name: "**Top Uploaders**",
                    value: uploaders,
                    inline: false,
                },
            )
            .setFooter({ text: `imgs.bar leaderboard`, iconURL: 'https://imgs.bar/logo.png' });

        return interaction.reply({ embeds: [embed] });
    }
};