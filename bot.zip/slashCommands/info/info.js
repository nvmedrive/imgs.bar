const { ApplicationCommandType, EmbedBuilder, ButtonBuilder, ActionRowBuilder } = require('discord.js');
const config = require('../../config.json');
const process = require('node:process')
require('dotenv').config()
module.exports = {
	name: 'info',
	description: "info for the bot itself",
	cooldown: 3000,
	run: async (client, interaction) => {
		
        const days = Math.floor(client.uptime / 86400000);
        const hours = Math.floor(client.uptime / 3600000) % 24;
        const minutes = Math.floor(client.uptime / 60000) % 60;
        const seconds = Math.floor(client.uptime / 1000) % 60;

        const embed = new EmbedBuilder()
        .setTitle("Imgs.bar Info")
        .addFields(
          {name: `MOTD`, value: "```" + "whats imgs.bar, imgs.bar better" + "```", inline: true})
        .addFields(
          {name: `Bot Developers`, value: "```" + `Sony Anderson#7266 and daddy Clynt#6169` + "```"})
        .addFields(
          {name: `Bot Version`, value: "```" + config.version + "```"})
        .addFields(
          {name: `Bot Ram Usage`, value: "```" + `${process.memoryUsage().rss / 1024 / 1024} MB` + "```"})
        .addFields(
          {name: `\n`, value: `\n`})
        .addFields(
          {name: `Uptime`, value: `\n`})
        .addFields(
          {name: `\n`, value: `\n`})
        .addFields(
            { name: "Days:", value: "```" + `${days}`+ "```", inline: true },
            { name: "Hours:", value: "```" + `${hours}`+ "```", inline: true },
            { name: "Minutes:", value: "```" + `${minutes}`+ "```", inline: true },
            { name: "Seconds:", value: "```" + `${seconds}`+ "```", inline: true },
          )
        .setColor(config.color)
        .setFooter({text: `imgs.bar`, iconURL: interaction.guild.iconURL()})
		return interaction.reply({ embeds: [embed] })
	}
};