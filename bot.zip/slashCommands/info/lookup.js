const { ApplicationCommandType, ApplicationCommandOptionType, EmbedBuilder, ButtonBuilder, ActionRowBuilder } = require('discord.js');
const config = require('../../config.json')
module.exports = {
    name: 'lookup',
    description: "lookup a user",
    cooldown: 3000,
    options: [
        {
            name: "user",
            description: "The user to lookup.",
            required: false,
            type: ApplicationCommandOptionType.String
        },
        {
            name: "id",
            description: "The id to lookup.",
            required: false,
            type: ApplicationCommandOptionType.Integer
        },
    ],
    run: async (client, interaction) => {

        const user = interaction.options.getString("user");
        const userid = interaction.options.getInteger("id");
        if (!userid && !user) {
            // get userid from discord id
            const req = await fetch(process.env.BACKEND + `/profile/get/discord/${interaction.user.id}`);
            const data = await req.json();
            if (data?.error) {
                return interaction.reply({
                    content: "This user don't exist",
                    ephemeral: true,
                });
            }
            const id = data?.data?.id ?? '';
            const username = data?.data?.username ?? '';
            const admin = data?.data?.admin ?? '';
            const invite_ban = data?.data?.invite_ban ?? '';
            const uploads = data?.data?.uploads ?? '';
            const created_at = data?.data?.created_at ?? '';
            const discord_id = data?.data?.discord_id ?? '';
            const discord_tag = data?.data?.discord_tag ?? '';
            const discord_avatar = data?.data?.discord_avatar ?? '';

            const created_at_date = new Date(created_at);
            const created_at_date_string = created_at_date.toDateString();

            const embed = new EmbedBuilder()
                .setColor(config.color)
                .setTitle("Lookup for " + username) 
                .setThumbnail(`${discord_avatar || 'https://imgs.bar/logo.png'}`)
                .addFields(
                    {
                        name: "**UID**",
                        value: ` **${id}**`,
                        inline: true,
                    },
                    {
                        name: "**Username**",
                        value: ` **${username}**`,
                        inline: true,
                    },
                    {
                        name: "**Uploads**",
                        value: ` **${uploads}**`,
                        inline: true,
                    },
                    {
                        name: "**Admin**",
                        value: ` **${admin}**`,
                        inline: false,
                    },
                    {
                        name: "**Invite Ban**",
                        value: ` **${invite_ban}**`,
                        inline: false,
                    },
                    {
                        name: "**Linked Discord**",
                        value: ` **${discord_tag}**`,
                        inline: false,
                    },
                    {
                        name: "**Discord ID**",
                        value: ` **${discord_id}**`,
                        inline: true,
                    },
                )
                .setFooter({ text: `Account created at ${created_at_date_string}`, iconURL: `${discord_avatar || 'https://imgs.bar/logo.png'}` });

            return interaction.reply({ embeds: [embed] })
            
        }
        if (user) {
            // https://api.imgs.bar/profile/get/<USERNAME>
            const req = await fetch(process.env.BACKEND + `/profile/get/${user}`);
            const data = await req.json();
            if (data?.error) {
                return interaction.reply({
                    content: "This user don't exist",
                    ephemeral: true,
                });
            }

            const id = data?.data?.id ?? '';
            const username = data?.data?.username ?? '';
            const admin = data?.data?.admin ?? '';
            const invite_ban = data?.data?.invite_ban ?? '';
            const uploads = data?.data?.uploads ?? '';
            const created_at = data?.data?.created_at ?? '';
            const discord_id = data?.data?.discord_id ?? '';
            const discord_tag = data?.data?.discord_tag ?? '';
            const discord_avatar = data?.data?.discord_avatar ?? '';


            const created_at_date = new Date(created_at);
            const created_at_date_string = created_at_date.toDateString();

            const embed = new EmbedBuilder()
                .setColor(config.color)
                .setTitle(`Lookup for ${user}`)
                .setThumbnail(`${discord_avatar || 'https://imgs.bar/logo.png'}`)
                .addFields(
                    {
                        name: "**UID**",
                        value: ` **${id}**`,
                        inline: true,
                    },
                    {
                        name: "**Username**",
                        value: ` **${username}**`,
                        inline: true,
                    },
                    {
                        name: "**Uploads**",
                        value: ` **${uploads}**`,
                        inline: true,
                    },
                    {
                        name: "**Admin**",
                        value: ` **${admin}**`,
                        inline: false,
                    },
                    {
                        name: "**Invite Ban**",
                        value: ` **${invite_ban}**`,
                        inline: false,
                    },
                    {
                        name: "**Linked Discord**",
                        value: ` **${discord_tag}**`,
                        inline: false,
                    },
                    {
                        name: "**Discord ID**",
                        value: ` **${discord_id}**`,
                        inline: true,
                    },
                )
                .setFooter({ text: `Account created at ${created_at_date_string}`, iconURL: `${discord_avatar || 'https://imgs.bar/logo.png'}` });

            return interaction.reply({ embeds: [embed] })
        }

        if (userid) {
            // https://api.imgs.bar/profile/get/id/<ID>
            const req = await fetch(process.env.BACKEND + `/profile/get/id/${userid}`);
            const data = await req.json();

            if (data?.error) {
                return interaction.reply({
                    content: "This user don't exist",
                    ephemeral: true,
                });
            }

            const id = data?.data?.id ?? '';
            const username = data?.data?.username ?? '';
            const admin = data?.data?.admin ?? '';
            const invite_ban = data?.data?.invite_ban ?? '';
            const uploads = data?.data?.uploads ?? '';
            const created_at = data?.data?.created_at ?? '';
            const discord_id = data?.data?.discord_id ?? '';
            const discord_tag = data?.data?.discord_tag ?? '';
            const discord_avatar = data?.data?.discord_avatar ?? '';


            const created_at_date = new Date(created_at);
            const created_at_date_string = created_at_date.toDateString();

            const userembed = new EmbedBuilder()
                .setColor(config.color)
                .setTitle(`Lookup for ${userid} (${username})`)
                .setThumbnail(`${discord_avatar || 'https://imgs.bar/logo.png'}`)
                .addFields(
                    {
                        name: "**UID**",
                        value: ` **${id}**`,
                        inline: true,
                    },
                    {
                        name: "**Username**",
                        value: ` **${username}**`,
                        inline: true,
                    },
                    {
                        name: "**Uploads**",
                        value: ` **${uploads}**`,
                        inline: true,
                    },
                    {
                        name: "**Admin**",
                        value: ` **${admin}**`,
                        inline: false,
                    },
                    {
                        name: "**Invite Ban**",
                        value: ` **${invite_ban}**`,
                        inline: false,
                    },
                    {
                        name: "**Linked Discord**",
                        value: ` **${discord_tag}**`,
                        inline: false,
                    },
                    {
                        name: "**Discord ID**",
                        value: ` **${discord_id}**`,
                        inline: true,
                    },
                )
                .setFooter({ text: `Account created at ${created_at_date_string}`, iconURL: `${discord_avatar || 'https://imgs.bar/logo.png'}` });

            await interaction.reply({ embeds: [userembed] })
        }
    }
};