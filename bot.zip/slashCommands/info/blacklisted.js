const { ApplicationCommandType, ApplicationCommandOptionType, EmbedBuilder, ButtonBuilder, ActionRowBuilder } = require('discord.js');
const config = require('../../config.json');
const fetch = require('node-fetch'); // Adding libs

module.exports = {
    name: 'blacklisted',
    description: "show balcklisted users on imgs.bar",
    cooldown: 3000,
    run: async (client, interaction) => {
        const req = await fetch(process.env.BACKEND + '/blacklisted');
        const data = await req.json();

        if (data?.error) {
            return interaction.reply({
                content: "Something went wrong!",
                ephemeral: true,
            });
        }

        let uploaders = "";
        for (let i = 0; i < data.data.length; i++) {
            const { blacklist, username } = data.data[i];
            uploaders += `**${i + 1}.** ${username} - ${blacklist} uploads\n`;
        }

        const embed = new EmbedBuilder()
            .setColor(config.color)
            .setTitle(`Blacklist || imgs.bar`)
            .setThumbnail('https://imgs.bar/logo.png')
            .addFields(
                {
                    name: "**Blacklisteds**",
                    value: uploaders,
                    inline: false,
                },
            )
            .setFooter({ text: `imgs.bar blacklisted users`, iconURL: 'https://imgs.bar/logo.png' });

        return interaction.reply({ embeds: [embed] });
    }
};