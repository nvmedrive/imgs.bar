const { ApplicationCommandType, ApplicationCommandOptionType, EmbedBuilder, ButtonBuilder, ActionRowBuilder } = require('discord.js');
const config = require('../../config.json')
module.exports = {
    name: 'stats',
    description: "show stats about imgs.bar",
    cooldown: 3000,
    run: async (client, interaction) => {

        // https://api.imgs.bar/profile/get/<USERNAME>
        const req = await fetch(`https://api.imgs.bar/stats`);
        const data = await req.json();
        if (data?.error) {
            return interaction.reply({
                content: "Something went wrong!",
                ephemeral: true,
            });
        }

        const domains = data?.data?.domains ?? '';
        const uploads = data?.data?.uploads ?? '';
        const users = data?.data?.users ?? '';

        const usedStorage = data?.data?.storage ?? '';
       

        const embed = new EmbedBuilder()
            .setColor(config.color)
            .setTitle(`Stats for imgs.bar`)
            .setThumbnail('https://imgs.bar/logo.png')
            .addFields(
                {
                    name: "**Domains**",
                    value: ` **${domains}**`,
                    inline: true,
                },
                {
                    name: "**Uploads**",
                    value: ` **${uploads}**`,
                    inline: true,
                },
                {
                    name: "**Users**",
                    value: ` **${users}**`,
                    inline: true,
                },
                {
                    name: "**Storage**",
                    value: ` **${usedStorage}**`,
                    inline: true,
                }
            )
            .setFooter({ text: `imgs.bar stats`, iconURL: 'https://imgs.bar/logo.png' });

        return interaction.reply({ embeds: [embed] })


    }
};