const { ApplicationCommandType, ApplicationCommandOptionType, EmbedBuilder, ButtonBuilder, ActionRowBuilder } = require('discord.js');
const config = require('../../config.json');

module.exports = {
	name: 'iplookup',
	description: "lookup a ip",
	cooldown: 3000,
	options: [
		{
			name: "ip",
			description: "ip to lookup",
			required: true,
			type: ApplicationCommandOptionType.String
		}
	],
	run: async (client, interaction) => {
		try {
			const ipAddress = interaction.options.getString("ip");
			await interaction.deferReply({ ephemeral: true });
			let embed = new EmbedBuilder()
				.setTitle(`IP Info for ${ipAddress}`)
				.setTimestamp()
				.setColor(config.color)
				.setFooter({ text: `imgs.bar`, iconURL: interaction.guild.iconURL() });

			const ipinfoApiResponse = await fetch(`https://ipinfo.io/${ipAddress}/json?token=ca5674a9551361`);
			const ipinfoData = await ipinfoApiResponse.json();
			if (ipinfoData.hostname) {
				embed = embed.setDescription(`
				rDNS: ${ipinfoData.hostname}
                Timezone: ${ipinfoData.timezone}`);
			} else {
					embed = embed.setDescription(`
				Timezone: ${ipinfoData.timezone}`);
			}
			await interaction.editReply({ embeds: [embed] });
			const ip2location = await fetch(`https://api.ip2location.io/?key=D7EFC7E9D1254B503876B8044F875DC0&ip=${ipAddress}`);
			const ip2locationData = await ip2location.json();
			if (ipinfoData.hostname) {
				embed = embed.setDescription(`
					rDNS: ${ipinfoData.hostname}
					Country: ${ip2locationData.country_name} | ${ip2locationData.country_code}
					City: ${ip2locationData.city_name}
					Region: ${ip2locationData.region_name}
					ZIP Code: ${ip2locationData.zip_code}
					Latitude: ${ip2locationData.latitude}
					Longitude: ${ip2locationData.longitude}
					Timezone: ${ipinfoData.timezone}`);
			} else {
				embed = embed.setDescription(`
					Country: ${ip2locationData.country_name} | ${ip2locationData.country_code}
					City: ${ip2locationData.city_name}
					Region: ${ip2locationData.region_name}
					ZIP Code: ${ip2locationData.zip_code}
					Latitude: ${ip2locationData.latitude}
					Longitude: ${ip2locationData.longitude}
					Timezone: ${ipinfoData.timezone}`);
			}
			await interaction.editReply({ embeds: [embed] });
            const req = await fetch(`http://ip-api.com/json/${ipAddress}`);
			const data = await req.json();
			if (ipinfoData.hostname) {
				embed = embed.setDescription(`
					rDNS: ${ipinfoData.hostname}
					Country: ${ip2locationData.country_name} | ${ip2locationData.country_code}
					City: ${ip2locationData.city_name}
					Region: ${ip2locationData.region_name} | ${data.region}
					ZIP Code: ${ip2locationData.zip_code}
					Latitude: ${ip2locationData.latitude}
					Longitude: ${ip2locationData.longitude}
					Timezone: ${ipinfoData.timezone}
					---------------------------------------------------------
					ORG: ${data.org}
					ISP: ${data.isp}
					ASN: ${ip2locationData.asn}`);
			} else {
				embed = embed.setDescription(`
					Country: ${ip2locationData.country_name} | ${ip2locationData.country_code}
					City: ${ip2locationData.city_name}
					Region: ${ip2locationData.region_name} | ${data.region}
					ZIP Code: ${ip2locationData.zip_code}
					Latitude: ${ip2locationData.latitude}
					Longitude: ${ip2locationData.longitude}
					Timezone: ${ipinfoData.timezone}
					---------------------------------------------------------
					ORG: ${data.org}
					ISP: ${data.isp}
					ASN: ${ip2locationData.asn}`);
			}
			await interaction.editReply({ embeds: [embed] });
		} catch (error) {
			console.error(error);
			return interaction.editReply({ content: 'An error occurred while processing the IP lookup.', ephemeral: true });
		}
	}
};
