const { ApplicationCommandType, ApplicationCommandOptionType, EmbedBuilder, ButtonBuilder, ActionRowBuilder } = require('discord.js');
const config = require('../../config.json');
const fetch = require('node-fetch'); // Adding libs

module.exports = {
    name: 'domains',
    description: "show all domains on imgs.bar",
    cooldown: 3000,
    run: async (client, interaction) => {
        const req = await fetch(process.env.BACKEND + '/domains');
        const data = await req.json();

        if (data?.error) {
            return interaction.reply({
                content: "Something went wrong!",
                ephemeral: true,
            });
        }

        const domains = data.data.join('\n'); // Converting array

        const embed = new EmbedBuilder()
            .setColor(config.color)
            .setTitle(`Domains || imgs.bar`)
            .setThumbnail('https://imgs.bar/logo.png')
            .addFields(
                {
                    name: "**Domains**",
                    value: `**${domains}**`,
                    inline: false,
                },
            )
            .setFooter({ text: `imgs.bar domains`, iconURL: 'https://imgs.bar/logo.png' });

        return interaction.reply({ embeds: [embed] });
    }
};