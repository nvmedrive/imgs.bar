const { ApplicationCommandType, EmbedBuilder } = require('discord.js');
const config = require('../../config.json');

module.exports = {
	name: 'membercount',
	description: "membercount",
	cooldown: 3000,
	run: async (client, interaction,) => {
    const members = await interaction.guild.members.fetch();
    const botCount = members.filter(member => member.user.bot).size;
    const embed = new EmbedBuilder()
    .addFields(
      {name: `Total Members`, value: `${interaction.guild.memberCount.toString()}`},
      {name: `Total Online Members`, value: `${members.filter(m => ["idle", "dnd", "online"].includes(m.presence?.status)).size}`},
      {name: `Total Bots`, value: `${botCount}`}
    )
    .setColor(config.color)
    .setTimestamp()
    return interaction.reply({ embeds: [embed] });
	}
};