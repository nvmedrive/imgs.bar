const { ApplicationCommandType, ApplicationCommandOptionType, EmbedBuilder, ButtonBuilder, ActionRowBuilder } = require('discord.js');
const config = require('../../config.json');
const whois = require('node-whois');
const dns = require('dns');
const rgx = /\b\.(aaa|aarp|abarth|abb|abbott|abbvie|abc|able|abogado|abudhabi|ac|academy|accenture|accountant|accountants|aco|active|actor|ad|adac|ads|adult|ae|aeg|aero|aetna|af|afamilycompany|afl|africa|ag|agakhan|agency|ai|aig|aigo|airbus|airforce|airtel|akdn|al|alfaromeo|alibaba|alipay|allfinanz|allstate|ally|alsace|alstom|am|amazon|americanexpress|americanfamily|amex|amfam|amica|amsterdam|analytics|android|anquan|anz|ao|aol|apartments|app|apple|aq|aquarelle|ar|arab|aramco|archi|army|arpa|art|arte|as|asda|asia|associates|at|athleta|attorney|au|auction|audi|audible|audio|auspost|author|auto|autos|avianca|aw|aws|ax|axa|az|azure|ba|baby|baidu|banamex|bananarepublic|band|bank|bar|barcelona|barclaycard|barclays|barefoot|bargains|baseball|basketball|bauhaus|bayern|bb|bbc|bbt|bbva|bcg|bcn|bd|be|beats|beauty|beer|bentley|berlin|best|bestbuy|bet|bf|bg|bh|bharti|bi|bible|bid|bike|bing|bingo|bio|biz|bj|black|blackfriday|blanco|blockbuster|blog|bloomberg|blue|bm|bms|bmw|bn|bnl|bnpparibas|bo|boats|boehringer|bofa|bom|bond|boo|book|booking|bosch|bostik|boston|bot|boutique|box|br|bradesco|bridgestone|broadway|broker|brother|brussels|bs|bt|budapest|bugatti|build|builders|business|buy|buzz|bv|bw|by|bz|bzh|ca|cab|cafe|cal|call|calvinklein|cam|camera|camp|cancerresearch|canon|capetown|capital|capitalone|car|caravan|cards|care|career|careers|cars|cartier|casa|case|caseih|cash|casino|cat|catering|catholic|cba|cbn|cbre|cbs|cc|cd|ceb|center|ceo|cern|cf|cfa|cfd|cg|ch|chanel|channel|charity|chase|chat|cheap|chintai|chloe|christmas|chrome|chrysler|church|ci|cipriani|circle|cisco|citadel|citi|citic|city|cityeats|ck|cl|claims|cleaning|click|clinic|clinique|clothing|cloud|club|clubmed|cm|cn|co|coach|codes|coffee|college|cologne|com|comcast|commbank|community|company|compare|computer|comsec|condos|construction|consulting|contact|contractors|cooking|cookingchannel|cool|coop|corsica|country|coupon|coupons|courses|cr|credit|creditcard|creditunion|cricket|crown|crs|cruise|cruises|csc|cu|cuisinella|cv|cw|cx|cy|cymru|cyou|cz|dabur|dad|dance|data|date|dating|datsun|day|dclk|dds|de|deal|dealer|deals|degree|delivery|dell|deloitte|delta|democrat|dental|dentist|desi|design|dev|dhl|diamonds|diet|digital|direct|directory|discount|discover|dish|diy|dj|dk|)\b/ //all available domains, there are probably more. if u want more add them here
module.exports = {
	name: 'domainlookup',
	description: "lookup a domain and receive info about it",
	cooldown: 3000,
    options: [  
        {
            name: "domain",
            description: "domain to lookup",
            required: true,
            type: ApplicationCommandOptionType.String
        }
    ],
	run: async (client, interaction) => {
        const domain = interaction.options.getString("domain");
        if(!rgx.test(domain)) {
            return interaction.reply({ content: `Given site is not valid`, ephemeral: true })
        } //ghetto but works

        whois.lookup(domain, async function(err, data) {
            if (err) {
                await interaction.reply({ content: "Sorry, I was unable to look up that domain." });
                return;
            }
            const registrarfix = data.match(/Registrar: (.+)/i);
            const registrar = registrarfix ? registrarfix[1] : 'Not Registered';
            const creationDateFix = data.match(/Creation Date: (.+)/i);
            const creationDate = creationDateFix ? new Date(creationDateFix[1]).toLocaleString() : '**';
            const expirationDateFix = data.match(/Expir\w+ Date: (.+)/i);
            const expirationDate = expirationDateFix ? new Date(expirationDateFix[1]).toLocaleString() : '**';
            const nameServersFix = data.match(/Name Server: (.+)/gi);
            const nameServers = nameServersFix ? nameServersFix.map(nameserver => nameserver.slice(12)).join(', ') : '**';

            dns.resolve(domain, async function(err) {
                const isAvailable = err ? true : false;

            const embed = new EmbedBuilder()
                .setColor(config.color)
                .setTitle(`Fetched information for ${domain}!`)
                .addFields(
                    {
                        name: "**Registrar**",
                        value: ` **${registrar}**`,
                        inline: false,
                    },
                    {
                        name: "**Creation Date**",
                        value: ` **${creationDate}**`,
                        inline: true,
                    },
                    {
                        name: "**Expiration Date**",
                        value: ` **${expirationDate}**`,
                        inline: true,
                    },
                    {
                        name: "**Can be Bought**",
                        value: ` **${isAvailable ? 'Yes' : 'No'}**`,
                        inline: false,
                    },
                    {
                        name: "**Name Servers**",
                        value: ` **${nameServers}**`,
                        inline: false,
                    },
                )// lol i actually didnt know that you can do this, this way
                .setTimestamp()
                .setFooter({text: "imgs.bar"});
            await interaction.reply({ embeds: [embed] });
        });
    }
  )}
}
