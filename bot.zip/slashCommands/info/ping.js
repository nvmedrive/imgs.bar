const { ApplicationCommandType, EmbedBuilder, ButtonBuilder, ActionRowBuilder } = require('discord.js');
const config = require('../../config.json');

module.exports = {
	name: 'ping',
	description: "Check bot's ping.",
	cooldown: 3000,
	run: async (client, interaction) => {
		let ping = Math.round(client.ws.ping) //do i need to explain?
		const embed = new EmbedBuilder()
		.setTitle('Pong!')
		.setDescription(`> Websocket Latenancy: **${ping}**ms`)
		.setColor(config.color)
		.setTimestamp()
		.setFooter({text: `imgs.bar`, iconURL: interaction.guild.iconURL()})

		const buttons = new ActionRowBuilder()
		.addComponents(
			new ButtonBuilder()
			.setLabel('💻 Discord Ping')
			.setURL("https://discordstatus.com/")
			.setStyle('Link'),
		);
		return interaction.reply({ embeds: [embed], components: [buttons] })
	}
};