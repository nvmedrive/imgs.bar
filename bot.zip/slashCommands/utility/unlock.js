const { ApplicationCommandType, EmbedBuilder, ApplicationCommandOptionType, ButtonBuilder,  ActionRowBuilder } = require('discord.js');
const config = require('../../config.json');

module.exports = {
	name: 'unlock',
	description: "unlock the given channel",
	cooldown: 3000,
    default_member_permissions: 'ManageChannels',
    options: [
	{
        name: "channel",
        type: ApplicationCommandOptionType.Channel,
        description: "The channel that u want to unlock",
        required: true,
        channel_types: [0]
    },
], 
	run: async (client, interaction) => {
        const channel = interaction.options.getChannel('channel');

        await channel.permissionOverwrites.edit(channel.guild.roles.everyone, {
            SendMessages: true
        });

        await interaction.reply(`<#${channel.id}> has been unlocked.`);
    },
};