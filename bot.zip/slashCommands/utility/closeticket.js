const { ApplicationCommandType, EmbedBuilder, ButtonBuilder, ActionRowBuilder } = require('discord.js');
const config = require('../../config.json');
const { createTranscript } = require('discord-html-transcripts');


module.exports = {
	name: 'closeticket',
	description: "close a active ticket.",
	cooldown: 3000,
    default_member_permissions: 'Administrator',
	run: async (client, interaction) => {
        const channel = client.channels.cache.get('1099392234748661820');  
        if (interaction.channel.name.startsWith('ticket-')) {
        await interaction.reply({ content: "Closing in 5 seconds!" }).then(
            setTimeout(() => {
                interaction.channel.delete()
            }, 5000)
        )
        const transcript = await createTranscript(channel, {
            limit: -1,
            returnBuffer: false,
            filename: `ticket-${interaction.user.username}.html`,
            saveImages: true, // Download all images and include the image data in the HTML (allows viewing the image even after it has been deleted) (! WILL INCREASE FILE SIZE !)
            poweredBy: false // Whether to include the "Powered by discord-html-transcripts" footer
        });
        const transcriptEmbed = new EmbedBuilder()
        .setAuthor({ name: `imgs.bar Transcripts`, iconURL: interaction.guild.iconURL() })
        .addFields(
          {name: `Closed by`, value: `${interaction.user.tag}`}
        )
        .setColor(config.color)
        await channel.send({ embeds: [transcriptEmbed], files: [transcript] }).catch(error => {
            console.error(error);
        });
	} else {
        interaction.reply({ content: "this is not a ticket!", ephemeral: true})
    }
}
};