const { ApplicationCommandType, EmbedBuilder, ButtonBuilder,  ActionRowBuilder, ApplicationCommandOptionType } = require('discord.js');
const config = require('../../config.json');

module.exports = {
	name: 'lock',
	description: "lock the given channel",
    default_member_permissions: 'ManageChannels',
	cooldown: 3000,
    options: [
	 {
        name: "channel",
        type: ApplicationCommandOptionType.Channel,
        description: "The channel that u want to lock",
        required: true,
        channel_types: [0]
    },
], 
	run: async (client, interaction) => {
        const channel = interaction.options.getChannel('channel');

        await channel.permissionOverwrites.edit(channel.guild.roles.everyone, {
            SendMessages: false
        });

        await interaction.reply(`<#${channel.id}> has been locked.`);
    },
};