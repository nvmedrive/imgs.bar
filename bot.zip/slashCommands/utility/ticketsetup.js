const { Client, CommandInteraction, EmbedBuilder, ButtonBuilder, ActionRowBuilder, ButtonStyle, AttachmentBuilder, ApplicationCommandOptionType, ChannelType } = require('discord.js');
const config = require('../../config.json');

module.exports = {
    name: 'ticketsetup',
    description: "ticket setup",
    default_member_permissions: 'Administrator',
    options: [
        {
            name: "channel",
            description: "provide channel to setup ticket",
            type: ApplicationCommandOptionType.Channel,
            required: true,
            channel_types: [0] //only channels
        },
        {
            name: 'embed_title',
            description: 'The ticket panel embed title.',
            type: ApplicationCommandOptionType.String,
            required: true
        },
        {
            name: 'embed_description',
            description: 'The ticket panel embed description.',
            type: ApplicationCommandOptionType.String,
            required: true
        },
    ],
    run: async (client, interaction) => {
        const title = interaction.options.get('embed_title').value;
        const description = interaction.options.get('embed_description').value;
        const channeldata = interaction.options.getChannel("channel");

        const embed = new EmbedBuilder()
        .setTitle(title)
        .setDescription(description)
        .setColor(config.color)
        .setFooter({ text: `imgs.bar`, iconURL: interaction.guild.iconURL() });

        const channel = interaction.guild.channels.cache.get(`${channeldata.id}`);
        if (!channel.viewable) {
            return interaction.reply({ content: "The provided channel is not visible to me", ephemeral: true })
        } //if the provided channel is not visible to the bot
        
        const button = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId(`ticket-setup-919531932054872065-1112031359955898379`) //first part the server id is the second part is the category id 
                    .setLabel('Ticket ✉️')
                    .setStyle('Primary')
            );

        await interaction.reply({ content: `The ticket has been setup to ${channel} successfully.`, ephemeral: true }) //if successful

        channel.send({ components: [button], embeds: [embed] }) 
        //this will send the button and embed
    }
}