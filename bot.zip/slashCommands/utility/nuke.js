const { ApplicationCommandType, EmbedBuilder } = require('discord.js');
const config = require('../../config.json');

module.exports = {
	name: 'nuke',
	description: "Nuke the Channel",
    default_member_permissions: 'ManageChannels',
	cooldown: 3000,
	run: async (client, message) => {
        let newchannel = await message.channel.clone()
        await message.channel.delete()
            await newchannel.send('https://tenor.com/view/explosion-mushroom-cloud-atomic-bomb-bomb-boom-gif-4464831').then(async (msg) => setTimeout(() => msg.delete(), 5000))
    }
};
//nuke server!!!!!!!!!!