const { ApplicationCommandType, EmbedBuilder, ButtonBuilder, ActionRowBuilder } = require('discord.js');
const config = require('../../config.json')
module.exports = {
	name: 'admin',
	description: "Admin Help Panel.",
	type: ApplicationCommandType.ChatInput,
	cooldown: 3000,
    default_member_permissions: 'Administrator',
	run: async (client, interaction) => {
        const embed = new EmbedBuilder()
		.setTitle('Admin Menu')
		.setDescription(`Run **Admin Only** Commands for imgs.bar host`)
		.setColor(config.color)
		.setTimestamp()

		const invitewave = new ActionRowBuilder()
		.addComponents(
			new ButtonBuilder()
			.setLabel('Invite Wave')
            .setEmoji("🌊")
			.setStyle("Primary")
            .setCustomId("invite_wave") //this needs to be the same as the button name in module exports in invite_wave.js
		);

		return interaction.reply({ embeds: [embed], components: [invitewave], ephemeral: true})
	}
};