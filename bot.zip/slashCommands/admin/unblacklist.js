

const { ApplicationCommandType, ApplicationCommandOptionType, EmbedBuilder, ButtonBuilder, ActionRowBuilder } = require('discord.js');
const config = require('../../config.json')
module.exports = {
    name: 'unblacklist',
    description: "unblacklist a user",
    cooldown: 3000,
    default_member_permissions: 'Administrator',
    options: [
        {
            name: "username",
            description: "The user to unblacklist.",
            required: true,
            type: ApplicationCommandOptionType.String
        },
    ],
    run: async (client, interaction) => {

        const username = interaction.options.getString("username");
        if (!username) {
            return interaction.reply({ content: `Please provide a valid username`, ephemeral: true })
        }

        const data = `{"token": "${process.env.KEY}", "username": "${username}"`;

        const result = await fetch(process.env.BACKEND + '/bot/unblacklist', {
            method: 'post',
            body: data,
            headers: { 'Content-Type': 'application/json' },

        }).then(res => res.json()).then(json => {

            if (json.error) return interaction.reply({ content: json.error, ephemeral: true });

            interaction.reply({ content: json.message, ephemeral: true });

        }).catch(err => {
            console.log(err);
            interaction.reply({ content: 'An error occurred while running this command!', ephemeral: true });
        });
    }
};