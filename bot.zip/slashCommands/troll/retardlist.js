const { ApplicationCommandType, EmbedBuilder, ButtonBuilder, ActionRowBuilder } = require('discord.js');
const config = require('../../config.json');
const fs = require('fs')

module.exports = {
	name: 'retardlist',
	description: "check who is on the retard list.",
	cooldown: 3000,
	run: async (client, interaction) => {
            const data = fs.readFileSync('retardusers.json');
            const retardusers = JSON.parse(data);
            const ids = retardusers.map(ids => `**${ids}**`).join('\n');
            const embed = new EmbedBuilder()
            .setColor(config.color)
            .setTitle('Retarded Users')
            .setDescription(`The following ids are in the retard list:\n${ids}`);
            await interaction.reply({ embeds: [embed] });
        } 
	};