const { ApplicationCommandType, EmbedBuilder, ButtonBuilder, ActionRowBuilder } = require('discord.js');
const config = require('../../config.json');
const fs = require('fs')

module.exports = {
	name: 'trollist',
	description: "check who is on the troll list.",
	cooldown: 3000,
	run: async (client, interaction) => {
            const data = fs.readFileSync('trollusers.json');
            const trollUsers = JSON.parse(data);
            const ids = trollUsers.map(ids => `**${ids}**`).join('\n');
            const embed = new EmbedBuilder()
            .setColor(config.color)
            .setTitle('Troll Users')
            .setDescription(`The following ids are in the troll list:\n${ids}`);
            await interaction.reply({ embeds: [embed] });
        } 
	};