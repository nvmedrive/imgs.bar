const { ApplicationCommandOptionType, EmbedBuilder } = require('discord.js');
const config = require('../../config.json');
const fs = require('fs')
module.exports = {
	name: 'atu',
	description: "add a user to the troll list",
	cooldown: 3000,
    default_member_permissions: 'Administrator',
    options: [
        {
            name: "user",
            description: "The user to add.",
            required: true,
            type: ApplicationCommandOptionType.User
        },  
        {
            name: "remove",
            description: "(false to add, true to remove)",
            required: true,
            type: ApplicationCommandOptionType.Boolean
        },  
    ],
	run: async (client, interaction) => {
        const user = interaction.options.getMember('user');
        const removeUser = interaction.options.getBoolean('remove');

        if (!user) {
            const embed = new EmbedBuilder()
            .setDescription("Please select a user to add or remove from the list.")
            .setColor(config.color)
            await interaction.reply({embeds: [embed]});
            return;
        }

        //load existing list of troll users
        let trollList = [];
        try {
            const data = fs.readFileSync('trollusers.json');
            trollList = JSON.parse(data);
        } catch (error) {
            console.error(error);
        }

        if (removeUser) {
            //remove user from the list
            const index = trollList.indexOf(user.id);
            if (index === -1) {
                const embed = new EmbedBuilder()
                .setDescription("This user is not in the troll users list.")
                .setColor(config.color)
                await interaction.reply({embeds: [embed]});
                return;
            }
            trollList.splice(index, 1);
        } else {
            //check if user is already in the list
            if (trollList.includes(user.id)) {
                const embed = new EmbedBuilder()
                .setDescription("This user is already in the troll users list.")
                .setColor(config.color)
                await interaction.reply({embeds: [embed]});
                return;
            }

            //add user to the list
            trollList.push(user.id);
        }
        try {
            //store updated list in trollusers.json
            fs.writeFileSync('trollusers.json', JSON.stringify(trollList));
            const action = removeUser ? 'removed from' : 'added to'; //from boolean
            const embed = new EmbedBuilder()
            .setDescription(`${user} (${user.id}) has been ${action} the troll list`)
            .setColor(config.color)
            await interaction.reply({embeds: [embed]});
        } catch (error) {
            console.error(error);
            const embed = new EmbedBuilder()
            .setDescription("Failed to add the user")
            .setColor(config.color)
            await interaction.reply({embeds: [embed]});
        }
    }
};