const { ApplicationCommandOptionType, EmbedBuilder } = require('discord.js');
const config = require('../../config.json');
const fs = require('fs')
module.exports = {
	name: 'aru',
	description: "add a user to the retard list",
	cooldown: 3000,
    default_member_permissions: 'Administrator',
    options: [
        {
            name: "user",
            description: "The user id to add.",
            required: true,
            type: ApplicationCommandOptionType.String
        },  
        {
            name: "remove",
            description: "(false to add, true to remove)",
            required: true,
            type: ApplicationCommandOptionType.Boolean
        },  
    ],
	run: async (client, interaction) => {
        const user = interaction.options.getString('user');
        const removeUser = interaction.options.getBoolean('remove');

        if (!/^\d+$/.test(user)) {
            const embed = new EmbedBuilder()
            .setDescription("Input a user ID not random letters")
            .setColor(config.color)
            await interaction.reply({embeds: [embed]});
            return;
        }

        if (!user) {
            const embed = new EmbedBuilder()
            .setDescription("Please select a user to add or remove from the list.")
            .setColor(config.color)
            await interaction.reply({embeds: [embed]});
            return;
        }
        //load existing list of retard users
        let retardlist = [];
        try {
            const data = fs.readFileSync('retardusers.json');
            retardlist = JSON.parse(data);
        } catch (error) {
            console.error(error);
        }
        if (removeUser) {
            //remove user from the list
            const index = retardlist.indexOf(user)
            if (index === -1) {
                const embed = new EmbedBuilder()
                .setDescription("This user is not in the retarded users list.")
                .setColor(config.color)
                await interaction.reply({embeds: [embed]});
                return;
            }
            retardlist.splice(index, 1);
        } else {
            //check if user is already in the list
            if (retardlist.includes(user)) {
                const embed = new EmbedBuilder()
                .setDescription("This user is already in the retardeds users list.")
                .setColor(config.color)
                await interaction.reply({embeds: [embed]});
                return;
            }

            //add user to the list
            retardlist.push(user);
        }
        try {
            //store updated list in retardusers.json
            fs.writeFileSync('retardusers.json', JSON.stringify(retardlist));
            const action = removeUser ? 'removed from' : 'added to'; //from boolean
            const embed = new EmbedBuilder()
            .setDescription(`${user} has been ${action} the retard list`)
            .setColor(config.color)
            await interaction.reply({embeds: [embed]});
        } catch (error) {
            console.error(error);
            const embed = new EmbedBuilder()
            .setDescription("Failed to add the user")
            .setColor(config.color)
            await interaction.reply({embeds: [embed]});
        }
    }
};