const { ApplicationCommandOptionType, EmbedBuilder } = require('discord.js');
const config = require('../../config.json'); //ok wtf i didnt update it?

module.exports = {
	name: 'dm',
	description: "send a user a dm :troll:",
    default_member_permissions: 'Administrator',
	cooldown: 3000,
    options: [
        {
            name: "user",
            description: "The user to dm.",
            required: true,
            type: ApplicationCommandOptionType.User
        },   
        {
            name: "message",
            description: "string to dm",
            required: true,
            type: ApplicationCommandOptionType.String
        }
    ],
	run: async (client, interaction) => {
        const user = interaction.options.getMember("user"); //fetches the user
        const message = interaction.options.getString('message'); //fetches the message string option

        if(user.id === client.user.id) {
            return await interaction.reply({
                content: "You cannot dm me dumb nigga"
            }) //if member decides to dm imgs.bar bot, it replies with this
        }
        user.send(message).catch(async (err) => {
            console.log(err)
            return await interaction.editReply({
                content: `Error, i can't send the DM`
            })
        })//if error
        await interaction.reply({content: `Dmed <@${user.id}>`})
	}
};