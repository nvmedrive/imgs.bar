const client = require('..');
const config = require('../config.json');
const fs = require('fs')

client.on("guildMemberOffline", (member, oldStatus) => {
    const channel = client.channels.cache.get("1111656540164870204");  //this is the channel id where the user(s) are going to get pinged 
    const trollList = JSON.parse(fs.readFileSync('trollusers.json'));
    if (trollList.includes(member.user.id)) {
    channel.send({ content: `a faggot became offline fuck you <@${member.id}>\n__**Want to add more users? type /atu**__` })
    }
  });