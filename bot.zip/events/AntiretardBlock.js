const client = require('..');
const { EmbedBuilder, AuditLogEvent } = require('discord.js');
const config = require('../config.json');
const fs = require('fs')

client.on("guildMemberAdd", async member => {
    const channel = client.channels.cache.get("1111929580496900126");
    const retardlist = JSON.parse(fs.readFileSync('retardusers.json'));
    if (retardlist.includes(member.user.id)) {
    member.kick("Kicked by the Anti-Retard System")
    channel.send(`${member.user.tag} got kicked by the anti retard system <:kekw:923745035818778655>`) 
    console.log(`${member.user.tag} got kicked by the anti retard system`) 
    }
});