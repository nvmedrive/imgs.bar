const { EmbedBuilder, ActionRowBuilder, ButtonBuilder} = require('discord.js')
const client = require('..');
const config = require('../config.json');

client.on("guildMemberUpdate", (oldMember, newMember) => {
    const oldStatus = oldMember.premiumSince;
    const newStatus = newMember.premiumSince;

    if(!oldStatus && newStatus) {
        client.channels.cache.get("1099392234748661820").send({ content: `<@${newMember.user.id}> just boosted the server!`})

        // api to update user role on website


    }

    if(oldStatus && !newStatus) {
        client.channels.cache.get("1099392234748661820").send({ content: `<@${newMember.user.id}> just unboosted the server!`})

        // api to update user role on website

    }

})