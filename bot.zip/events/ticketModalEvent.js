const client = require('..');
const { ActionRowBuilder, ButtonBuilder, ChannelType, EmbedBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ButtonStyle } = require('discord.js');
const config = require('../config.json')
const { createTranscript } = require('discord-html-transcripts');

client.on("interactionCreate", async (interaction) => {
    if (interaction.isModalSubmit()) {
        if (interaction.customId.startsWith(`modal-919531932054872065`)) { //server id
            const id = interaction.customId.split('-')[2]
            const domains = interaction.fields.getTextInputValue('ticket-domains');
            const help = interaction.fields.getTextInputValue('ticket-help');
            const category = interaction.guild.channels.cache.get(`${id}`)
            await interaction.guild.channels.create({
                parent: category.id,
                name: `ticket-${interaction.user.username}`,
                permissionOverwrites: [
                    {
                        id: interaction.guild.id,
                        deny: ['ViewChannel'],
                    },
                    {
                        id: interaction.member.id,
                        allow: ['ViewChannel', 'SendMessages', 'ReadMessageHistory'],
                    },
                ],
                topic: interaction.user.id,
                type: ChannelType.GuildText,
            }).then(async c => {
                interaction.reply({ content: `The ticket has been created in <#${c.id}>`, ephemeral: true });

                const embed = new EmbedBuilder()
                    .addFields(
                        { name: "Domain(s) that want to be submitted", value: "```"+`${domains || "No Domains"}`+"```" }
                    )
                    .addFields(
                        { name: "Help", value: "```"+`${help || "No Help Needed"}`+"```" }
                    )
                    .setColor(config.color)

                    const embed2 = new EmbedBuilder()
                    .setTitle(`${interaction.user.username} Don't worry we are here to Help!`)
                    .setAuthor({ name: `Welcome ${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL() })
                    .setDescription(`Thanks for creating your ticket <@${interaction.user.id}>! Our staff will assist your shortly.`)
                    .setColor(config.color)

                    c.send({ embeds: [embed2] }) //content: `${interaction.user} <@&${config.ticketsupportrole}>`,
                    c.send({ embeds: [embed] })
            })
        }
    }
});