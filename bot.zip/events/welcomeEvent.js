const { EmbedBuilder, ActionRowBuilder, ButtonBuilder} = require('discord.js')
const client = require('..');
const config = require('../config.json');

client.on("guildMemberAdd", async member => {   
    const req = await fetch(`https://api.imgs.bar/profile/get/discord/${member.user.id}`);
    const data = await req.json();
    const username = data?.data?.username ?? '';
    const discord_avatar = data?.data?.discord_avatar ?? '';
    const id = data?.data?.id ?? '';
    const normalchannel = client.channels.cache.get("1099392234748661820");
    const logchannel = client.channels.cache.get("1099392234748661820");

    const role = member.guild.roles.cache.find(role => role.id === "949119290353786930");
    member.roles.add(role)

    if (member.user.bot) {
      logchannel.send({ content: `Hey ${member.user.username} we do not care that you joined because you're a bot!`});
    } else {

    const embedwelcome = new EmbedBuilder()
    .setAuthor({ name: "Member Joined", iconURL: `${discord_avatar || 'https://imgs.bar/logo.png'}` })
    .setDescription(`Hey <@${member.user.id}>! Thanks for Joining imgs.bar\nWe hope you have a **great** time!\nLinked Account: ${username || `No Linked Account`}`)
    .setColor(config.color)
    .setThumbnail(`${discord_avatar || 'https://imgs.bar/logo.png'}`)
    .setFooter({text: `imgs.bar`, iconURL: member.guild.iconURL()})
    .setTimestamp(new Date())

    const embed = new EmbedBuilder()
    .setAuthor({ name: "Member Joined", iconURL: member.user.displayAvatarURL() })
    .setDescription(`<@${member.user.id}> ${member.user.tag} joined <t:${parseInt(member.joinedAt / 1000)}:R>`)
    .setColor(config.color)
    .setThumbnail(`${discord_avatar || 'https://imgs.bar/logo.png'}`)
    .setFooter({text: `imgs.bar`})
    .setTimestamp(new Date())
    .addFields(
        { name: `Account Created`, value: `<t:${parseInt(member.user.createdAt / 1000)}:R>`, inline: true },
        { name: `ID`, value: `${member.id}`, inline: true }
      )

    await logchannel.send({ embeds: [embed] });
    await normalchannel.send({ embeds: [embedwelcome] });
    }
});