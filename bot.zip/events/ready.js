const { ActivityType } = require('discord.js');
const client = require('..');
const chalk = require('chalk');

require('dotenv').config()
client.on("ready", () => {
	let i = 0;
	const guild = client.guilds.cache.get('919531932054872065');
	setInterval(() => {
		const memberCount = guild.memberCount;
		const channel = guild.channels.cache.get('1111707180438130878')
		channel.setName(`Total Members: ${memberCount.toLocaleString()}`)
	}, 600000); //updates every 10 minutes

	setInterval(() => {
		const boostcount = guild.premiumSubscriptionCount;
		const channel = guild.channels.cache.get('1111707486412615793')
		channel.setName(`Total Boosts: ${boostcount.toLocaleString()}`)
	}, 600000); //updates every 10 minutes
	setInterval(() => {
		if(i >= process.env.DISCORDACTIVITY.length) i = 0
		client.user.setActivity(process.env.DISCORDACTIVITY)
		i++;
	}, 5000);

	let s = 0;
	setInterval(() => {
		if(s >= process.env.DISCORDACTIVITY.length) s = 0
		client.user.setStatus(process.env.DISCORDSTATUS)
		s++;
	}, 30000);
	console.log(chalk.red(`Logged in as ${client.user.tag}!`))


});