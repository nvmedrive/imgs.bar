
const { ApplicationCommandType, EmbedBuilder, ButtonBuilder, ActionRowBuilder } = require('discord.js');
const config = require('../config.json');

const data = `{"token": "${process.env.KEY}"}`;

module.exports = {
	id: 'invite_wave',
	permissions: ["Administrator"],
	run: async (client, interaction) => {
		const result = await fetch(process.env.BACKEND + '/bot/wave', {
			method: 'post',
			body: data,
			headers: { 'Content-Type': 'application/json' },

		}).then(res => res.json()).then(json => {

			if (json.error) return interaction.reply({ content: json.error, ephemeral: true });

			// interaction.reply({ content: json.message, ephemeral: true });
			const embed = new EmbedBuilder()
				.setTitle('Waves')
				.setDescription(`Invite wave successfully sent!`)
				.setColor(config.color)
				.setTimestamp()
			return interaction.reply({ embeds: [embed]});

		}).catch(err => {
			console.log(err);
			interaction.reply({ content: 'An error occurred while running this command!', ephemeral: true });
		});
	}
};