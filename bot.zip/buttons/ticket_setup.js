const { ActionRowBuilder, ButtonBuilder, ChannelType, EmbedBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ButtonStyle } = require('discord.js');
module.exports = {
	id: 'ticket-setup-919531932054872065-1112031359955898379', //first part the server id is the second part is the category id 
	run: async (client, interaction) => {
        let alreadyticket = interaction.guild.channels.cache.find(c => c.topic === `${interaction.member.id}`)
        if (alreadyticket) return interaction.reply({ content: `You already have a ticket opened in ${alreadyticket}!`, ephemeral: true })
        const id = interaction.customId.split('-')[3]

        const modal = new ModalBuilder()
        .setCustomId(`modal-${interaction.guild.id}-${id}`)
        .setTitle(`${interaction.guild.name}'s Ticket`);
            
        const domains = new TextInputBuilder()
        .setCustomId(`ticket-domains`)
        .setLabel("Sumbit Domain(s)")
        .setPlaceholder("Type your domain here.")
        .setRequired(false)
        .setStyle(TextInputStyle.Short)
        .setMinLength(5)
        .setMaxLength(1000);

        const help = new TextInputBuilder()
        .setCustomId(`ticket-help`)
        .setLabel("Need help?")
        .setPlaceholder("e.g: how do i download my config?" )
        .setRequired(false)
        .setStyle(TextInputStyle.Short)
        .setMinLength(5)
        .setMaxLength(1000);

        const firstActionRow = new ActionRowBuilder().addComponents(domains);

        const secondActionRow = new ActionRowBuilder().addComponents(help);


        modal.addComponents(firstActionRow, secondActionRow,);

        await interaction.showModal(modal);
	}
};