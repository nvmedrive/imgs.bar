/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./index.html",
    "./src/**/*.{js,svelte}",
    './node_modules/tw-elements/dist/js/**/*.js'
  ],
  theme: {
    extend: {
      colors: {
        "main": "#06B6D4"
      },
      backgroundImage: {
        'backimg': "url('https://cdn.discordapp.com/attachments/919533264119677018/1100115158283583488/20230424_194441_0000.png')"
      }
    },
  },
  plugins: [
    require('flowbite/plugin')
  ],
}
