import { writable } from 'svelte/store';

export const admin = writable(true);
export const loggedIn = writable(true);
export const username = writable("Clynt");
export const uid = writable("1");