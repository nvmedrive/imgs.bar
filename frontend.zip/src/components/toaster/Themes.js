export const error = {theme: {
    '--toastBarBackground': '#d44b06'
}}

export const success = {theme: {
    '--toastBarBackground': '#06d409'
}}