<script>
    export let title;
    export let additional = '';
</script>

<div class="h-full w-full bg-gray-600 rounded-t bg-clip-padding backdrop-filter backdrop-blur-lg bg-opacity-50  p-4  {additional}">
    <h3 class="max-w-sm font-bold text-left text-3xl text-ellipsis overflow-hidden">{title}</h3>
    <slot />
</div>
