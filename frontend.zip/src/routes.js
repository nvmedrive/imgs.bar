import Home from "./routes/Home.svelte";
import Login from "./routes/Login.svelte";
import Register from "./routes/Register.svelte";
import Gallery from "./routes/dashboard/Gallery.svelte";
import Admin from "./routes/Admin.svelte";
import NotFound from "./routes/NotFound.svelte";
import Index from "./routes/dashboard/Index.svelte";
import Settings from "./routes/dashboard/Settings.svelte";
import Report from "./routes/Report.svelte";
import Embed from "./routes/dashboard/Embed.svelte";
import Account from "./routes/dashboard/Account.svelte";
import Bio from "./routes/dashboard/Bio.svelte";
import Privacy from "./routes/Privacy.svelte";
import Terms from "./routes/Terms.svelte";
import Verify from "./routes/dashboard/Verify.svelte";

export const routes = {
  "/": Home,
  "/login": Login,
  "/register": Register,
  "/dashboard": Index,
  "/dashboard/admin": Admin,
  "/dashboard/gallery": Gallery,
  "/dashboard/settings": Settings,
  "/dashboard/verify": Verify,
  "/dashboard/embed": Embed,
  "/dashboard/account": Account,
  "/dashboard/bio": Bio,
  "/privacy": Privacy,
  "/terms": Terms,
  "/report": Report,
  "*": NotFound,
};
