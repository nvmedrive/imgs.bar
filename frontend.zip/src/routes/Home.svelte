<script>
	import { onMount } from "svelte";
	import { loggedIn } from "../stores";

	loggedIn.subscribe((v) => {
		if (v) {
			location.href = "/#/dashboard";
		}
	});

	let users = null;
	let uploads = null;
	let domains = null;

	const getData = () => {
		fetch("https://api.imgs.bar/stats", {}).then((res) => {
			res.json().then((data) => {
				users = data.data.users;
				uploads = data.data.uploads;
				domains = data.data.domains;
			});
		});
	};

	onMount(async () => {
		getData();
	});
</script>

<svelte:head>
	<meta property="og:title" content="imgs.bar — file hosting" />
	<meta property="og:url" content="https://imgs.bar/" />
	<meta property="og:image" content="https://imgs.bar/logo.png" />
	<meta
		property="og:description"
		content="A fast, reliable, private and privacy oritented file hosting service."
	/>
</svelte:head>

<div>
	<header class="jst-container flex h-screen bg-hero bg-cover">
		<img
			src="https://cdn.discordapp.com/attachments/919533264119677018/1100115158283583488/20230424_194441_0000.png"
			alt=""
			class="absolute object-fill w-full h-screen"
		/>
		<div class="mt-12 px-6 flex mx-auto h-[100vh] relative">
			<div class="items-center md:flex m-auto">
				<div class="w-full">
					<div
						class="text-center space-y-4 items-center flex flex-col mx-auto justify-center"
					>
						<div class="flex flex-col items-center space-y-2">
							<h1
								class="flex justify-center sm:p-12 font-semibold text-transparent text-2xl sm:text-7xl"
							>
								<span class="text-white">imgs</span><span
									class="bg-clip-text bg-gradient-to-r from-blue-500 to-blue-900"
									>.bar</span
								>
							</h1>
							<p
								class="text-gray-300 max-w-xl font-semibold text-md sm:text-lg sm:mt-0 text-center"
							>
								A fast, reliable, private and <span
									class="text-red-500 font-semibold"
									>privacy oritented</span
								> file hosting service.
							</p>
						</div>
						<div class="flex justify-center gap-2">
							<div
								class="flex w-full max-w-xs gap-2"
								style="marginTop: 8px "
							>
								<a href="/#/login">
									<button
										class="mt-3 w-full rounded-lg border border-blue-600 p-1 px-3 text-lg text-gray-200 transition-all hover:border-blue-700 hover:bg-blue-700"
										>Login</button
									>
								</a>

								<a href="/#/register">
									<button
										class="mt-3 w-full rounded-lg border border-blue-600 p-1 px-3 text-lg text-gray-200 transition-all hover:border-blue-700 hover:bg-blue-700"
									>
										Register</button
									>
								</a>

								<a href="https://discord.com/invite/upload/">
									<button
										class="mt-3 flex w-full items-center rounded-lg border border-[#5865F2] p-1 px-3 text-lg text-gray-200 transition-all hover:border-[#404EED] hover:bg-[#404EED]"
									>
										<div class="m-auto flex items-center">
											<svg
												xmlns="http://www.w3.org/2000/svg"
												width="16"
												height="16"
												fill="currentColor"
												class="mr-1"
												viewBox="0 0 16 16"
											>
												<path
													d="M13.545 2.907a13.227 13.227 0 0 0-3.257-1.011.05.05 0 0 0-.052.025c-.141.25-.297.577-.406.833a12.19 12.19 0 0 0-3.658 0 8.258 8.258 0 0 0-.412-.833.051.051 0 0 0-.052-.025c-1.125.194-2.22.534-3.257 1.011a.041.041 0 0 0-.021.018C.356 6.024-.213 9.047.066 12.032c.001.014.01.028.021.037a13.276 13.276 0 0 0 3.995 2.02.05.05 0 0 0 .056-.019c.308-.42.582-.863.818-1.329a.05.05 0 0 0-.01-.059.051.051 0 0 0-.018-.011 8.875 8.875 0 0 1-1.248-.595.05.05 0 0 1-.02-.066.051.051 0 0 1 .015-.019c.084-.063.168-.129.248-.195a.05.05 0 0 1 .051-.007c2.619 1.196 5.454 1.196 8.041 0a.052.052 0 0 1 .053.007c.08.066.164.132.248.195a.051.051 0 0 1-.004.085 8.254 8.254 0 0 1-1.249.594.05.05 0 0 0-.03.03.052.052 0 0 0 .003.041c.24.465.515.909.817 1.329a.05.05 0 0 0 .056.019 13.235 13.235 0 0 0 4.001-2.02.049.049 0 0 0 .021-.037c.334-3.451-.559-6.449-2.366-9.106a.034.034 0 0 0-.02-.019Zm-8.198 7.307c-.789 0-1.438-.724-1.438-1.612 0-.889.637-1.613 1.438-1.613.807 0 1.45.73 1.438 1.613 0 .888-.637 1.612-1.438 1.612Zm5.316 0c-.788 0-1.438-.724-1.438-1.612 0-.889.637-1.613 1.438-1.613.807 0 1.451.73 1.438 1.613 0 .888-.631 1.612-1.438 1.612Z"
												/>
											</svg>
											Discord
										</div>
									</button>
								</a>
							</div>
						</div>
						<div class="space-x-2">
							<div
								class="flex mx-auto justify-center space-x-2"
							/>
							<div
								class="mt-3 text-gray-300 flex flex-col items-center"
							>
								<!-- add a button that when you press it the page scroll to div with id download -->
								<a href="#/">
									<svg
										xmlns="http://www.w3.org/2000/svg"
										fill="none"
										viewBox="0 0 24 24"
										stroke-width="1.5"
										stroke="currentColor"
										aria-hidden="true"
										class="animate-bounce mt-2 h-5 w-5"
									>
										<path
											stroke-linecap="round"
											stroke-linejoin="round"
											d="M19.5 13.5L12 21m0 0l-7.5-7.5M12 21V3"
										/>
									</svg>
								</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>
	<div id="/" class="flex flex-col min-h-screen bg-[#0e0e0f]">
		<main class="flex-grow space-y-24">
			<!-- Features -->

			<section class="bg-[#0e0e0f] py-24">
				<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
					<div class="css-0" style="animation-delay:0ms">
						<div class="text-center">
							<div class="space-y-2">
								<h1
									class="text-3xl leading-8 font-medium tracking-tight text-blue-500 sm:text-4xl"
								>
									Features
								</h1>
							</div>
						</div>
					</div>
					<div class="mt-10">
						<div
							class="mx-6 md:mx-0 space-y-3 md:space-y-0 md:grid md:grid-cols-2 md:gap-x-6 md:gap-y-5 mt-3 grid lg:grid-cols-3 sm:grid-cols-1 gap-3"
						>
							<!-- Fast -->
							<div
								class="flex flex-col items-center justify-center bg-zinc-900 py-6 px-6 relative overflow-hidden transition duration-200 transform rounded shadow-lg hover:scale-105"
							>
								<div
									class="flex items-center justify-center h-12 w-12 rounded-md bg-blue-500 text-white"
								>
									<svg
										xmlns="http://www.w3.org/2000/svg"
										fill="none"
										viewBox="0 0 24 24"
										stroke-width="1.5"
										stroke="currentColor"
										class="w-6 h-6"
									>
										<path
											stroke-linecap="round"
											stroke-linejoin="round"
											d="M3.75 13.5l10.5-11.25L12 10.5h8.25L9.75 21.75 12 13.5H3.75z"
										/>
									</svg>
								</div>
								<div class="mt-5">
									<h4
										class="text-lg leading-6 font-medium text-gray-300"
									>
										Fast
									</h4>
									<p
										class="mt-2 text-base leading-6 text-gray-400"
									>
										Our API is fast and reliable, we use the
										best servers to provide you the best
										experience.
									</p>
								</div>
							</div>

							<!-- Secure -->
							<div
								class="flex flex-col items-center justify-center bg-zinc-900 py-6 px-6 relative overflow-hidden transition duration-200 transform rounded shadow-lg hover:scale-105"
							>
								<div
									class="flex items-center justify-center h-12 w-12 rounded-md bg-blue-500 text-white"
								>
									<svg
										xmlns="http://www.w3.org/2000/svg"
										fill="none"
										viewBox="0 0 24 24"
										stroke-width="1.5"
										stroke="currentColor"
										class="w-6 h-6"
									>
										<path
											stroke-linecap="round"
											stroke-linejoin="round"
											d="M9 12.75L11.25 15 15 9.75m-3-7.036A11.959 11.959 0 013.598 6 11.99 11.99 0 003 9.749c0 5.592 3.824 10.29 9 11.623 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.285z"
										/>
									</svg>
								</div>
								<div class="mt-5">
									<h4
										class="text-lg leading-6 font-medium text-gray-300"
									>
										Privacy
									</h4>
									<p
										class="mt-2 text-base leading-6 text-gray-400"
									>
										Your privacy is our priority, that's why
										there are regular updates that improve
										security.
									</p>
								</div>
							</div>

							<!-- Customizable -->
							<div
								class="flex flex-col items-center justify-center bg-zinc-900 py-6 px-6 relative overflow-hidden transition duration-200 transform rounded shadow-lg hover:scale-105"
							>
								<div
									class="flex items-center justify-center h-12 w-12 rounded-md bg-blue-500 text-white"
								>
									<svg
										xmlns="http://www.w3.org/2000/svg"
										fill="none"
										viewBox="0 0 24 24"
										stroke-width="1.5"
										stroke="currentColor"
										class="w-6 h-6"
									>
										<path
											stroke-linecap="round"
											stroke-linejoin="round"
											d="M10.343 3.94c.09-.542.56-.94 1.11-.94h1.093c.55 0 1.02.398 1.11.94l.149.894c.07.424.384.764.78.93.398.164.855.142 1.205-.108l.737-.527a1.125 1.125 0 011.45.12l.773.774c.39.389.44 1.002.12 1.45l-.527.737c-.25.35-.272.806-.107 1.204.165.397.505.71.93.78l.893.15c.543.09.94.56.94 1.109v1.094c0 .55-.397 1.02-.94 1.11l-.893.149c-.425.07-.765.383-.93.78-.165.398-.143.854.107 1.204l.527.738c.32.447.269 1.06-.12 1.45l-.774.773a1.125 1.125 0 01-1.449.12l-.738-.527c-.35-.25-.806-.272-1.203-.107-.397.165-.71.505-.781.929l-.149.894c-.09.542-.56.94-1.11.94h-1.094c-.55 0-1.019-.398-1.11-.94l-.148-.894c-.071-.424-.384-.764-.781-.93-.398-.164-.854-.142-1.204.108l-.738.527c-.447.32-1.06.269-1.45-.12l-.773-.774a1.125 1.125 0 01-.12-1.45l.527-.737c.25-.35.273-.806.108-1.204-.165-.397-.505-.71-.93-.78l-.894-.15c-.542-.09-.94-.56-.94-1.109v-1.094c0-.55.398-1.02.94-1.11l.894-.149c.424-.07.765-.383.93-.78.165-.398.143-.854-.107-1.204l-.527-.738a1.125 1.125 0 01.12-1.45l.773-.773a1.125 1.125 0 011.45-.12l.737.527c.35.25.807.272 1.204.107.397-.165.71-.505.78-.929l.15-.894z"
										/>
										<path
											stroke-linecap="round"
											stroke-linejoin="round"
											d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
										/>
									</svg>
								</div>
								<div class="mt-5">
									<h4
										class="text-lg leading-6 font-medium text-gray-300"
									>
										Customizable
									</h4>
									<p
										class="mt-2 text-base leading-6 text-gray-400"
									>
										imgs.bar is completely customizable
										according to the user's wishes.
									</p>
								</div>
							</div>

							<!-- Uptime -->
							<div
								class="flex flex-col items-center justify-center bg-zinc-900 py-6 px-6 relative overflow-hidden transition duration-200 transform rounded shadow-lg hover:scale-105"
							>
								<div
									class="flex items-center justify-center h-12 w-12 rounded-md bg-blue-500 text-white"
								>
									<svg
										xmlns="http://www.w3.org/2000/svg"
										fill="none"
										viewBox="0 0 24 24"
										stroke-width="1.5"
										stroke="currentColor"
										class="w-6 h-6"
									>
										<path
											stroke-linecap="round"
											stroke-linejoin="round"
											d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z"
										/>
									</svg>
								</div>
								<div class="mt-5">
									<h4
										class="text-lg leading-6 font-medium text-gray-300"
									>
										Uptime
									</h4>
									<p
										class="mt-2 text-base leading-6 text-gray-400"
									>
										You can fully trust imgs.bar thanks to
										98.99% uptime
									</p>
								</div>
							</div>

							<!-- file support -->
							<div
								class="flex flex-col items-center justify-center bg-zinc-900 py-6 px-6 relative overflow-hidden transition duration-200 transform rounded shadow-lg hover:scale-105"
							>
								<div
									class="flex items-center justify-center h-12 w-12 rounded-md bg-blue-500 text-white"
								>
									<svg
										xmlns="http://www.w3.org/2000/svg"
										fill="none"
										viewBox="0 0 24 24"
										stroke-width="1.5"
										stroke="currentColor"
										class="w-6 h-6"
									>
										<path
											stroke-linecap="round"
											stroke-linejoin="round"
											d="M10.343 3.94c.09-.542.56-.94 1.11-.94h1.093c.55 0 1.02.398 1.11.94l.149.894c.07.424.384.764.78.93.398.164.855.142 1.205-.108l.737-.527a1.125 1.125 0 011.45.12l.773.774c.39.389.44 1.002.12 1.45l-.527.737c-.25.35-.272.806-.107 1.204.165.397.505.71.93.78l.893.15c.543.09.94.56.94 1.109v1.094c0 .55-.397 1.02-.94 1.11l-.893.149c-.425.07-.765.383-.93.78-.165.398-.143.854.107 1.204l.527.738c.32.447.269 1.06-.12 1.45l-.774.773a1.125 1.125 0 01-1.449.12l-.738-.527c-.35-.25-.806-.272-1.203-.107-.397.165-.71.505-.781.929l-.149.894c-.09.542-.56.94-1.11.94h-1.094c-.55 0-1.019-.398-1.11-.94l-.148-.894c-.071-.424-.384-.764-.781-.93-.398-.164-.854-.142-1.204.108l-.738.527c-.447.32-1.06.269-1.45-.12l-.773-.774a1.125 1.125 0 01-.12-1.45l.527-.737c.25-.35.273-.806.108-1.204-.165-.397-.505-.71-.93-.78l-.894-.15c-.542-.09-.94-.56-.94-1.109v-1.094c0-.55.398-1.02.94-1.11l.894-.149c.424-.07.765-.383.93-.78.165-.398.143-.854-.107-1.204l-.527-.738a1.125 1.125 0 01.12-1.45l.773-.773a1.125 1.125 0 011.45-.12l.737.527c.35.25.807.272 1.204.107.397-.165.71-.505.78-.929l.15-.894z"
										/>
										<path
											stroke-linecap="round"
											stroke-linejoin="round"
											d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
										/>
									</svg>
								</div>
								<div class="mt-5">
									<h4
										class="text-lg leading-6 font-medium text-gray-300"
									>
										All file types
									</h4>
									<p
										class="mt-2 text-base leading-6 text-gray-400"
									>
										We at imgs.bar allow you to host any
										kind of files. It does not matter if
										image files or large .zip files.
									</p>
								</div>
							</div>

							<!-- friendly -->

							<div
								class="flex flex-col items-center justify-center bg-zinc-900 py-6 px-6 relative overflow-hidden transition duration-200 transform rounded shadow-lg hover:scale-105"
							>
								<div
									class="flex items-center justify-center h-12 w-12 rounded-md bg-blue-500 text-white"
								>
									<svg
										xmlns="http://www.w3.org/2000/svg"
										fill="none"
										viewBox="0 0 24 24"
										stroke-width="1.5"
										stroke="currentColor"
										class="w-6 h-6"
									>
										<path
											stroke-linecap="round"
											stroke-linejoin="round"
											d="M15.182 15.182a4.5 4.5 0 01-6.364 0M21 12a9 9 0 11-18 0 9 9 0 0118 0zM9.75 9.75c0 .414-.168.75-.375.75S9 10.164 9 9.75 9.168 9 9.375 9s.375.336.375.75zm-.375 0h.008v.015h-.008V9.75zm5.625 0c0 .414-.168.75-.375.75s-.375-.336-.375-.75.168-.75.375-.75.375.336.375.75zm-.375 0h.008v.015h-.008V9.75z"
										/>
									</svg>
								</div>
								<div class="mt-5">
									<h4
										class="text-lg leading-6 font-medium text-gray-300"
									>
										Friendly
									</h4>
									<p
										class="mt-2 text-base leading-6 text-gray-400"
									>
										Besides our safety, we at imgs.bar pride
										ourselves on our friendly staff!
									</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>

			<!-- Testimonials -->

			<section class="bg-[#0e0e0f]">
				<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
					<div class="css-0" style="animation-delay:0ms">
						<div class="text-center">
							<div class="space-y-2">
								<h1
									class="text-3xl leading-8 font-medium tracking-tight text-blue-500 sm:text-4xl"
								>
									Testimonials
								</h1>
								<span
									class="text-sm font-semibold text-neutral-500"
									>What do our users say about us?</span
								>
							</div>
						</div>
					</div>
					<div class="mt-10">
						<div
							class="mx-6 md:mx-0 space-y-3 md:space-y-0 md:grid md:grid-cols-2 md:gap-x-6 md:gap-y-5 mt-3 grid lg:grid-cols-3 sm:grid-cols-1 gap-3"
						>
							<div
								class="relative md:h-full bg-neutral-900 p-3 rounded-xl shadow-md transform transition duration-500 hover:scale-105"
							>
								<div>
									<div
										class="absolute flex items-center justify-center duration-300 ease-in-out text-white"
									>
										<img
											src="https://cdn.discordapp.com/attachments/1064788520880840746/1111605174067269672/Picsart_23-05-26_12-42-02-148.png"
											alt="Testimonial Avatar"
											class="rounded-full h-12 w-12"
											aria-hidden="true"
										/>
									</div>
									<p
										class="ml-16 text-lg leading-6 font-medium text-gray-300"
									>
										XTC#1337
									</p>
								</div>
								<p class="mt-2 ml-16 text-base text-gray-400">
									A privacy-oriented image uploader that
									respects user privacy and security. Highly
									recommended! By the XTC Team!
								</p>
							</div>

							<div
								class="relative md:h-full bg-neutral-900 p-3 rounded-xl shadow-md transform transition duration-500 hover:scale-105"
							>
								<div>
									<div
										class="absolute flex items-center justify-center duration-300 ease-in-out text-white"
									>
										<img
											src="https://cdn.discordapp.com/avatars/786388578355642378/cddeb715b2b20875973a6d1b5b4a3a30.webp?size=2048"
											alt="Testimonial Avatar"
											class="rounded-full h-12 w-12"
											aria-hidden="true"
										/>
									</div>
									<p
										class="ml-16 text-lg leading-6 font-medium text-gray-300"
									>
										Pathetic#1337
									</p>
								</div>
								<p class="mt-2 ml-16 text-base text-gray-400">
									imgs.bar is a reliable image host that i use
									daily i also know the owners and they are
									very nice along with the rest of the
									community and to note clynt is a kraut sack
									of ass but i love him (no homo) 10/10 image
									host
								</p>
							</div>

							<div
								class="relative md:h-full bg-neutral-900 p-3 rounded-xl shadow-md transform transition duration-500 hover:scale-105"
							>
								<div>
									<div
										class="absolute flex items-center justify-center duration-300 ease-in-out text-white"
									>
										<img
											src="https://cdn.discordapp.com/avatars/939943313249796147/d04d1e33b0cc16177d2a3b04d5e0f311.webp?size=2048"
											alt="Testimonial Avatar"
											class="rounded-full h-12 w-12"
											aria-hidden="true"
										/>
									</div>
									<p
										class="ml-16 text-lg leading-6 font-medium text-gray-300"
									>
										iVers#7848
									</p>
								</div>
								<p class="mt-2 ml-16 text-base text-gray-400">
									"Very fast, high quality images, sexy ui.
									10/10" idk what else to say
								</p>
							</div>

							<div
								class="relative md:h-full bg-neutral-900 p-3 rounded-xl shadow-md transform transition duration-500 hover:scale-105"
							>
								<div>
									<div
										class="absolute flex items-center justify-center duration-300 ease-in-out text-white"
									>
										<img
											src="https://cdn.discordapp.com/avatars/992470767822446682/a05c3d00653dc24e52e616940e17a295.webp?size=2048"
											alt="Testimonial Avatar"
											class="rounded-full h-12 w-12"
											aria-hidden="true"
										/>
									</div>
									<p
										class="ml-16 text-lg leading-6 font-medium text-gray-300"
									>
									HackYT#1337
									</p>
								</div>
								<p class="mt-2 ml-16 text-base text-gray-400">
									"reliable service, works fast and i use it often, 10/10 would smash clynt"
								</p>
							</div>
						</div>
					</div>
				</div>
			</section>

			<!-- Stats -->

			<section class="bg-[#0e0e0f] py-24">
				<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
					<div class="css-0" style="animation-delay:0ms">
						<div class="text-center">
							<div class="space-y-2">
								<h1
									class="text-3xl leading-8 font-medium tracking-tight text-blue-500 sm:text-4xl"
								>
									Stats
								</h1>
							</div>
						</div>
					</div>
					<div class="mt-10">
						<div
							class="mx-6 md:mx-0 space-y-3 md:space-y-0 md:grid md:grid-cols-2 md:gap-x-6 md:gap-y-5 mt-3 grid lg:grid-cols-3 sm:grid-cols-1 gap-3"
						>
							<!-- USers -->
							<div
								class="flex flex-col items-center justify-center bg-zinc-900 py-6 px-6 relative overflow-hidden transition duration-200 transform rounded shadow-lg hover:scale-105"
							>
								<div
									class="flex items-center justify-center h-12 w-12 rounded-md bg-blue-500 text-white"
								>
									<svg
										xmlns="http://www.w3.org/2000/svg"
										fill="none"
										viewBox="0 0 24 24"
										stroke-width="1.5"
										stroke="currentColor"
										class="w-6 h-6"
									>
										<path
											stroke-linecap="round"
											stroke-linejoin="round"
											d="M15 19.128a9.38 9.38 0 002.625.372 9.337 9.337 0 004.121-.952 4.125 4.125 0 00-7.533-2.493M15 19.128v-.003c0-1.113-.285-2.16-.786-3.07M15 19.128v.106A12.318 12.318 0 018.624 21c-2.331 0-4.512-.645-6.374-1.766l-.001-.109a6.375 6.375 0 0111.964-3.07M12 6.375a3.375 3.375 0 11-6.75 0 3.375 3.375 0 016.75 0zm8.25 2.25a2.625 2.625 0 11-5.25 0 2.625 2.625 0 015.25 0z"
										/>
									</svg>
								</div>
								<div class="mt-5">
									<h4
										class="text-lg leading-6 font-medium text-gray-300"
									>
										Total users
									</h4>
									<p
										class="mt-2 text-base leading-6 text-gray-400"
									>
										{ users }
									</p>
								</div>
							</div>

							<!-- Uploads -->
							<div
								class="flex flex-col items-center justify-center bg-zinc-900 py-6 px-6 relative overflow-hidden transition duration-200 transform rounded shadow-lg hover:scale-105"
							>
								<div
									class="flex items-center justify-center h-12 w-12 rounded-md bg-blue-500 text-white"
								>
									<svg
										xmlns="http://www.w3.org/2000/svg"
										fill="none"
										viewBox="0 0 24 24"
										stroke-width="1.5"
										stroke="currentColor"
										class="w-6 h-6"
									>
										<path
											stroke-linecap="round"
											stroke-linejoin="round"
											d="M7.5 7.5h-.75A2.25 2.25 0 004.5 9.75v7.5a2.25 2.25 0 002.25 2.25h7.5a2.25 2.25 0 002.25-2.25v-7.5a2.25 2.25 0 00-2.25-2.25h-.75m0-3l-3-3m0 0l-3 3m3-3v11.25m6-2.25h.75a2.25 2.25 0 012.25 2.25v7.5a2.25 2.25 0 01-2.25 2.25h-7.5a2.25 2.25 0 01-2.25-2.25v-.75"
										/>
									</svg>
								</div>
								<div class="mt-5">
									<h4
										class="text-lg leading-6 font-medium text-gray-300"
									>
										Uploads
									</h4>
									<p
										class="mt-2 text-base leading-6 text-gray-400"
									>
										{ uploads }
									</p>
								</div>
							</div>

							<!-- Customizable -->
							<div
								class="flex flex-col items-center justify-center bg-zinc-900 py-6 px-6 relative overflow-hidden transition duration-200 transform rounded shadow-lg hover:scale-105"
							>
								<div
									class="flex items-center justify-center h-12 w-12 rounded-md bg-blue-500 text-white"
								>
									<svg
										xmlns="http://www.w3.org/2000/svg"
										fill="none"
										viewBox="0 0 24 24"
										stroke-width="1.5"
										stroke="currentColor"
										class="w-6 h-6"
									>
										<path
											stroke-linecap="round"
											stroke-linejoin="round"
											d="M12 21a9.004 9.004 0 008.716-6.747M12 21a9.004 9.004 0 01-8.716-6.747M12 21c2.485 0 4.5-4.03 4.5-9S14.485 3 12 3m0 18c-2.485 0-4.5-4.03-4.5-9S9.515 3 12 3m0 0a8.997 8.997 0 017.843 4.582M12 3a8.997 8.997 0 00-7.843 4.582m15.686 0A11.953 11.953 0 0112 10.5c-2.998 0-5.74-1.1-7.843-2.918m15.686 0A8.959 8.959 0 0121 12c0 .778-.099 1.533-.284 2.253m0 0A17.919 17.919 0 0112 16.5c-3.162 0-6.133-.815-8.716-2.247m0 0A9.015 9.015 0 013 12c0-1.605.42-3.113 1.157-4.418"
										/>
									</svg>
								</div>
								<div class="mt-5">
									<h4
										class="text-lg leading-6 font-medium text-gray-300"
									>
										Domains
									</h4>
									<p
										class="mt-2 text-base leading-6 text-gray-400"
									>
										{ domains }
									</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
		</main>
		<footer class="bg-zinc-800" aria-labelledby="footerHeading">
			<h2 id="footerHeading" class="sr-only">Footer</h2>
			<div class="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:py-16 lg:px-8">
				<div class="md:grid md:grid-cols-3 md:gap-8">
					<div class="space-y-8 md:col-span-1">
						<h3
							class="text-sm font-semibold text-gray-400 tracking-wider uppercase"
						>
							Socials
						</h3>
						<div class="flex space-x-6">
							<a
								href="https://discord.gg/upload"
								class="text-gray-400 hover:text-gray-200 transition duration-200 ease-in-out"
							>
								<span class="sr-only">Discord</span>
								<svg
									fill="currentColor"
									viewBox="0 0 640 512"
									class="h-6 w-6"
									aria-hidden="true"
									name="Discord"
								>
									<path
										fill-rule="evenodd"
										d="M524.531,69.836a1.5,1.5,0,0,0-.764-.7A485.065,485.065,0,0,0,404.081,32.03a1.816,1.816,0,0,0-1.923.91,337.461,337.461,0,0,0-14.9,30.6,447.848,447.848,0,0,0-134.426,0,309.541,309.541,0,0,0-15.135-30.6,1.89,1.89,0,0,0-1.924-.91A483.689,483.689,0,0,0,116.085,69.137a1.712,1.712,0,0,0-.788.676C39.068,183.651,18.186,294.69,28.43,404.354a2.016,2.016,0,0,0,.765,1.375A487.666,487.666,0,0,0,176.02,479.918a1.9,1.9,0,0,0,2.063-.676A348.2,348.2,0,0,0,208.12,430.4a1.86,1.86,0,0,0-1.019-2.588,321.173,321.173,0,0,1-45.868-21.853,1.885,1.885,0,0,1-.185-3.126c3.082-2.309,6.166-4.711,9.109-7.137a1.819,1.819,0,0,1,1.9-.256c96.229,43.917,200.41,43.917,295.5,0a1.812,1.812,0,0,1,1.924.233c2.944,2.426,6.027,4.851,9.132,7.16a1.884,1.884,0,0,1-.162,3.126,301.407,301.407,0,0,1-45.89,21.83,1.875,1.875,0,0,0-1,2.611,391.055,391.055,0,0,0,30.014,48.815,1.864,1.864,0,0,0,2.063.7A486.048,486.048,0,0,0,610.7,405.729a1.882,1.882,0,0,0,.765-1.352C623.729,277.594,590.933,167.465,524.531,69.836ZM222.491,337.58c-28.972,0-52.844-26.587-52.844-59.239S193.056,219.1,222.491,219.1c29.665,0,53.306,26.82,52.843,59.239C275.334,310.993,251.924,337.58,222.491,337.58Zm195.38,0c-28.971,0-52.843-26.587-52.843-59.239S388.437,219.1,417.871,219.1c29.667,0,53.307,26.82,52.844,59.239C470.715,310.993,447.538,337.58,417.871,337.58Z"
									/>
								</svg>
							</a>
						</div>
					</div>
					<div
						class="mt-12 grid grid-cols-2 gap-8 md:mt-0 col-span-4 lg:col-span-2"
					>
						<div class="md:grid md:grid-cols-2 md:gap-8">
							<div>
								<h3
									class="text-sm font-semibold text-gray-400 tracking-wider uppercase"
								>
									Legal
								</h3>
								<ul class="mt-4 space-y-4">
									<li>
										<a
											href="/#/privacy"
											class="text-base text-gray-400 hover:text-gray-500 transition duration-200 ease-in-out"
										>
											Privay Policy
										</a>
									</li>
									<li>
										<a
											href="/#/terms"
											class="text-base text-gray-400 hover:text-gray-500 transition duration-200 ease-in-out"
										>
											Terms of Use
										</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
				<div class="mt-12 border-t-2 border-neutral-700 pt-8">
					<p class="text-base text-gray-400">
						© <!-- -->2023<!-- --> imgs.bar - All rights reserved.
					</p>
				</div>
			</div>
		</footer>
	</div>
</div>
