<script>
    import { ArrowLeftIcon } from "svelte-feather-icons";
    import { toast } from "@zerodevx/svelte-toast";
    import { error, success } from "../components/toaster/Themes";

    let form = {};
    let response = {};

    async function report(token) {
        // @ts-ignore
        const url = "https://api.imgs.bar/files/report";
        const data = {
            reporter_username: form.reporter_username,
            file_id: form.file_id,
        };
        const response = await fetch(url, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(data),
        });

        if (response.status === 200) {
            toast.push("Report sent", success);
        }
    }
</script>

<svelte:head>
    <script src="https://www.google.com/recaptcha/api.js"></script>
</svelte:head>
<div class="flex h-screen">
    <div class="m-auto p-4">
        <div class="flex justify-between">
            <p class="font-bold text-left text-3xl">Report File</p>
            <a
                href="#/"
                class="p-1 rounded-full bg-neutral-800 text-xs font-bold my-auto text-neutral-400"
            >
                <ArrowLeftIcon size="20" />
            </a>
        </div>
        <form
            method="post"
            class="grid grid-cols-1 mt-2"
            on:submit|preventDefault={report}
        >
            <input
                type="text"
                placeholder="Your Username"
                class="w-80 bg-neutral-800 outline-none text-sm px-2 py-px rounded-lg"
                bind:value={form.reporter_username}
                required
            />
            <input
                type="text"
                placeholder="File ID"
                class="w-80 bg-neutral-800 outline-none text-sm px-2 py-px rounded-lg mt-1"
                bind:value={form.file_id}
                required
            />
            <button
                type="submit"
                class="mt-4 px-4 py-px font-bold rounded-lg bg-red-700 shadow-lg shadow-red-500/60"
            >
                Report
            </button>
        </form>
    </div>
</div>
