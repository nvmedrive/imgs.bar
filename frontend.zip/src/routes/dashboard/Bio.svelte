<script>
    // @ts-nocheck

    import { loggedIn, username } from "../../stores";
    import { toast } from "@zerodevx/svelte-toast";
    import { error, success } from "../../components/toaster/Themes";
    import { onMount } from "svelte";

    let isLoggedIn = false;
    loggedIn.subscribe((v) => {
        isLoggedIn = v;
        if (!v) {
            location.href = "/";
        }
    });

    let form = {
        embeddesc: "",
        embedcolor: "",
        logourl: "",
        description: "",
        youtube: "",
        reddit: "",
        twitch: "",
        pinterest: "",
        linkedin: "",
        github: "",
        paypal: "",
    };


    const getProfile = () => {
        fetch("https://api.imgs.bar/preferences/get/profile", {
            credentials: "include",
        }).then((res) =>
            res.json().then((data) => {
                user = data.data.username;
            })
        );
    };

    onMount(async () => {
        getProfile();
    });


    let response = {};


    async function changeBio() {
        await fetch("https://api.imgs.bar/preferences/change/bio", {
            method: "post",
            headers: {
                "Content-type": "application/json",
            },
            credentials: "include",
            body: JSON.stringify(form),
        }).then((res) => {
            res.json().then((data) => {
                if (res.status !== 200) {
                    toast.push(data.message, error);
                } else {
                    toast.push(data.message, success);
                }
            });
        });
    }

    function toggleSidebar() {
        const sidebar = document.getElementById("default-sidebar");
        const sidebarToggle = document.getElementById("sidebar-toggle");

        sidebar.classList.toggle("-translate-x-full");
        sidebarToggle.classList.toggle("rotate-180");
        const mainContent = document.getElementById("main-content");
        mainContent.classList.toggle("blur");
    }
</script>

{#if isLoggedIn}
    <div class="flex flex-col flex-1 w-full bg-zinc-900">
        <header class="z-10 py-8 bg-zinc-800">
            <div
                class="container flex items-center justify-between h-full px-6 mx-auto text-purple-600 dark:text-purple-300"
            />
        </header>
        <button
            id="sidebar-toggle"
            on:click={toggleSidebar}
            type="button"
            class="inline-flex items-center p-2 mt-2 ml-3 text-sm text-white rounded-lg sm:hidden dark:text-gray-400"
        >
            <span class="sr-only">Open sidebar</span>
            <svg
                class="w-6 h-6"
                aria-hidden="true"
                fill="currentColor"
                viewBox="0 0 20 20"
                xmlns="http://www.w3.org/2000/svg"
            >
                <path
                    clip-rule="evenodd"
                    fill-rule="evenodd"
                    d="M2 4.75A.75.75 0 012.75 4h14.5a.75.75 0 010 1.5H2.75A.75.75 0 012 4.75zm0 10.5a.75.75 0 01.75-.75h7.5a.75.75 0 010 1.5h-7.5a.75.75 0 01-.75-.75zM2 10a.75.75 0 01.75-.75h14.5a.75.75 0 010 1.5H2.75A.75.75 0 012 10z"
                />
            </svg>
        </button>

        <aside
            id="default-sidebar"
            class="fixed top-0 left-0 z-40 w-64 h-screen transition-transform -translate-x-full sm:translate-x-0"
            aria-label="Sidebar"
        >
            <div
                class="flex items-center justify-between flex-shrink-0 px-3 py-4 bg-zinc-800 dark:bg-gray-800"
            >
                <img
                    class="w-24 h-24"
                    src="https://cdn.discordapp.com/attachments/1064788520880840746/1111605174067269672/Picsart_23-05-26_12-42-02-148.png"
                    alt="Workflow"
                />
            </div>
            <div
                class="h-full px-3 py-4 overflow-y-aut bg-zinc-800 dark:bg-gray-800"
            >
                <ul class="space-y-2 font-medium">
                    <li>
                        <a
                            href="/#/dashboard"
                            class="flex items-center p-2 text-white rounded-lg dark:text-white hover:bg-gray-800
                dark:hover:bg-gray-700"
                        >
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke-width="1.5"
                                stroke="currentColor"
                                aria-hidden="true"
                                class="h-6 w-6 mr-2"
                            >
                                <path
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                    d="M3.75 6A2.25 2.25 0 016 3.75h2.25A2.25 2.25 0 0110.5 6v2.25a2.25 2.25 0 01-2.25 2.25H6a2.25 2.25 0 01-2.25-2.25V6zM3.75 15.75A2.25 2.25 0 016 13.5h2.25a2.25 2.25 0 012.25 2.25V18a2.25 2.25 0 01-2.25 2.25H6A2.25 2.25 0 013.75 18v-2.25zM13.5 6a2.25 2.25 0 012.25-2.25H18A2.25 2.25 0 0120.25 6v2.25A2.25 2.25 0 0118 10.5h-2.25a2.25 2.25 0 01-2.25-2.25V6zM13.5 15.75a2.25 2.25 0 012.25-2.25H18a2.25 2.25 0 012.25 2.25V18A2.25 2.25 0 0118 20.25h-2.25A2.25 2.25 0 0113.5 18v-2.25z"
                                />
                            </svg>
                            <span class="ml-3">Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a
                            href="/#/dashboard/gallery"
                            class="flex items-center p-2 text-white rounded-lg dark:text-white hover:bg-gray-800
                dark:hover:bg-gray-700"
                        >
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke-width="1.5"
                                stroke="currentColor"
                                aria-hidden="true"
                                class="h-6 w-6 mr-2"
                            >
                                <path
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                    d="M6 6.878V6a2.25 2.25 0 012.25-2.25h7.5A2.25 2.25 0 0118 6v.878m-12 0c.235-.083.487-.128.75-.128h10.5c.263 0 .515.045.75.128m-12 0A2.25 2.25 0 004.5 9v.878m13.5-3A2.25 2.25 0 0119.5 9v.878m0 0a2.246 2.246 0 00-.75-.128H5.25c-.263 0-.515.045-.75.128m15 0A2.25 2.25 0 0121 12v6a2.25 2.25 0 01-2.25 2.25H5.25A2.25 2.25 0 013 18v-6c0-.98.626-1.813 1.5-2.122"
                                />
                            </svg>
                            <span class="flex-1 ml-3 whitespace-nowrap"
                                >Files</span
                            >
                        </a>
                    </li>
                    <li>
                        <a
                            href="/#/dashboard/embed"
                            class="flex items-center p-2 text-white rounded-lg dark:text-white hover:bg-gray-800
                dark:hover:bg-gray-700"
                        >
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke-width="1.5"
                                stroke="currentColor"
                                aria-hidden="true"
                                class="h-6 w-6 mr-2"
                            >
                                <path
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                    d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L10.582 16.07a4.5 4.5 0 01-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 011.13-1.897l8.932-8.931zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0115.75 21H5.25A2.25 2.25 0 013 18.75V8.25A2.25 2.25 0 015.25 6H10"
                                />
                            </svg>
                            <span class="flex-1 ml-3 whitespace-nowrap"
                                >Embed</span
                            >
                        </a>
                    </li>
                    <li>
                        <a
                            href="/#/dashboard/settings"
                            class="flex items-center p-2 text-white rounded-lg dark:text-white hover:bg-gray-800
                dark:hover:bg-gray-700"
                        >
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke-width="1.5"
                                stroke="currentColor"
                                aria-hidden="true"
                                class="h-6 w-6 mr-2"
                            >
                                <path
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                    d="M4.5 12a7.5 7.5 0 0015 0m-15 0a7.5 7.5 0 1115 0m-15 0H3m16.5 0H21m-1.5 0H12m-8.457 3.077l1.41-.513m14.095-5.13l1.41-.513M5.106 17.785l1.15-.964m11.49-9.642l1.149-.964M7.501 19.795l.75-1.3m7.5-12.99l.75-1.3m-6.063 16.658l.26-1.477m2.605-14.772l.26-1.477m0 17.726l-.26-1.477M10.698 4.614l-.26-1.477M16.5 19.794l-.75-1.299M7.5 4.205L12 12m6.894 5.785l-1.149-.964M6.256 7.178l-1.15-.964m15.352 8.864l-1.41-.513M4.954 9.435l-1.41-.514M12.002 12l-3.75 6.495"
                                />
                            </svg>
                            <span class="flex-1 ml-3 whitespace-nowrap"
                                >Settings</span
                            >
                        </a>
                    </li>
                    <li>
                        <a
                            href="/#/dashboard/bio"
                            class="flex items-center p-2 text-white rounded-lg dark:text-white hover:bg-gray-800
                dark:hover:bg-gray-700"
                        >
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke-width="1.5"
                                stroke="currentColor"
                                class="h-6 w-6 mr-2"
                            >
                                <path
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                    d="M13.19 8.688a4.5 4.5 0 011.242 7.244l-4.5 4.5a4.5 4.5 0 01-6.364-6.364l1.757-1.757m13.35-.622l1.757-1.757a4.5 4.5 0 00-6.364-6.364l-4.5 4.5a4.5 4.5 0 001.242 7.244"
                                />
                            </svg>

                            <span class="flex-1 ml-3 whitespace-nowrap"
                                >Bio</span
                            >
                        </a>
                    </li>
                    <li>
                        <a
                            href="/#/dashboard/account"
                            class="flex items-center p-2 text-white rounded-lg dark:text-white hover:bg-gray-800
                dark:hover:bg-gray-700"
                        >
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke-width="1.5"
                                stroke="currentColor"
                                class="h-6 w-6 mr-2"
                            >
                                <path
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                    d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z"
                                />
                            </svg>

                            <span class="flex-1 ml-3 whitespace-nowrap"
                                >Account</span
                            >
                        </a>
                    </li>
                </ul>
            </div>
        </aside>

        <div id="main-content" class="p-4 sm:ml-64 bg-zinc-900">
            <div class="flex flex-row items-center justify-between">
                <div class="flex flex-col">
                    <h1 class="text-4xl font-semibold text-white">Bio</h1>
                    <div class="h-1 bg-blue-600 rounded w-10" />
                </div>
            </div>

            <div class="md:grid md:grid-cols-2 md:gap-6 px-4">
                <!-- Form -->
                <div class="mt-5 md:col-span-1 md:mt-0">
                    <form on:submit|preventDefault={changeBio}
                        id=""
                        class="mt-10 flex flex-col rounded-3xl space-y-9"
                    >
                        <div class="flex flex-col space-y-2">
                            <div class="flex flex-col space-y-1">
                                <input
                                bind:value={form.logourl}
                                    type="text"
                                    id="LogoUrl"
                                    name="LogoUrl"
                                    class="w-full px-4 py-2 rounded-xl bg-[#121212] border border-[#303030] text-neutral-200 focus:outline-none focus:border-blue-600"
                                    placeholder="Logo Url"
                                />
                            </div>
                            <div class="flex flex-col space-y-1">
                                <input
                                bind:value={form.youtube}
                                    type="text"
                                    id="YouTube"
                                    name="YouTube"
                                    class="w-full px-4 py-2 rounded-xl bg-[#121212] border border-[#303030] text-neutral-200 focus:outline-none focus:border-blue-600"
                                    placeholder="Youtube"
                                />
                            </div>
                            <div class="flex flex-col space-y-1">
                                <input
                                bind:value={form.twitch}
                                    type="text"
                                    id="Twitch"
                                    name="Twitch"
                                    class="w-full px-4 py-2 rounded-xl bg-[#121212] border border-[#303030] text-neutral-200 focus:outline-none focus:border-blue-600"
                                    placeholder="Twitch"
                                />
                            </div>
                            <div class="flex flex-col space-y-1">
                                <input
                                bind:value={form.reddit}
                                    type="text"
                                    id="reddit"
                                    name="reddit"
                                    class="w-full px-4 py-2 rounded-xl bg-[#121212] border border-[#303030] text-neutral-200 focus:outline-none focus:border-blue-600"
                                    placeholder="Reddit"
                                />
                            </div>
                            <div class="flex flex-col space-y-1">
                                <input
                                bind:value={form.paypal}
                                    type="text"
                                    id="paypal"
                                    name="paypal"
                                    class="w-full px-4 py-2 rounded-xl bg-[#121212] border border-[#303030] text-neutral-200 focus:outline-none focus:border-blue-600"
                                    placeholder="PayPal"
                                />
                            </div>
                            <div class="flex flex-col space-y-1">
                                <input
                                bind:value={form.github}
                                    type="text"
                                    id="github"
                                    name="github"
                                    class="w-full px-4 py-2 rounded-xl bg-[#121212] border border-[#303030] text-neutral-200 focus:outline-none focus:border-blue-600"
                                    placeholder="GitHub"
                                />
                            </div>
                            <div class="flex flex-col space-y-1">
                                <input
                                bind:value={form.linkedin}
                                    type="text"
                                    id="linkedin"
                                    name="linkedin"
                                    class="w-full px-4 py-2 rounded-xl bg-[#121212] border border-[#303030] text-neutral-200 focus:outline-none focus:border-blue-600"
                                    placeholder="LinkedIn"
                                />
                            </div>
                            <div class="flex flex-col space-y-1">
                                <input
                                bind:value={form.description}
                                    type="text"
                                    id="description"
                                    name="description"
                                    class="w-full px-4 py-2 rounded-xl bg-[#121212] border border-[#303030] text-neutral-200 focus:outline-none focus:border-blue-600"
                                    placeholder="Description"
                                />
                            </div>

                            <div class="flex flex-col space-y-1">
                                <input
                                bind:value={form.embeddesc}
                                    type="text"
                                    id="description"
                                    name="description"
                                    class="w-full px-4 py-2 rounded-xl bg-[#121212] border border-[#303030] text-neutral-200 focus:outline-none focus:border-blue-600"
                                    placeholder="Embed Description"
                                />
                            </div>

                            <div
                                class="px-2 flex w-90 bg-[#121212] rounded-xl mt-1 my-auto"
                            >
                                <input type="color" class="h-4 w-4 my-auto" bind:value={form.embedcolor} />
                                <input
                                    type="text" bind:value={form.embedcolor}
                                    class="bg-transparent w-full px-4 py-1 rounded-xl bg-[#121212] border border-[#303030] text-neutral-200 focus:outline-none focus:border-blue-600"
                                    placeholder="Color (use hex)"
                                />
                            </div>
                        </div>

                        <!-- save button -->
                        <div class="flex flex-col space-y-2">
                            <button
                                type="submit"
                                class="w-full px-4 py-2 text-lg font-semibold text-white transition-colors duration-200 transform bg-blue-600 rounded-xl hover:bg-blue-500 focus:bg-blue-500 focus:outline-none"
                            >
                                Save
                            </button>
                        </div>
                    </form>
                </div>

                <!-- Preview -->
                <div class="mt-5 md:col-span-1 md:mt-0">
                    <!-- iframe https://imgs.bio/Clynt -->
                    <iframe
                        title="bio"
                        src="https://imgs.bio/Clynt"
                        frameborder="0"
                        width="100%"
                        height="100%"
                        class="rounded-xl"
                    />
                </div>
            </div>
        </div>
    </div>
{/if}
