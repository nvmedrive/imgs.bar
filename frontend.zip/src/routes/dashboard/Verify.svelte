<script>
    import { loggedIn, uid, username } from "../../stores.js";
    import { onMount } from "svelte";

    let isLoggedIn = false;
    let usernameValue;
    let uidValue;

    let apiKey = null;
    let verified = null;

    const getProfile = () => {
        fetch("https://api.imgs.bar/preferences/get/profile", {
            credentials: "include",
        }).then((res) =>
            res.json().then((data) => {
                apiKey = data.data.api_key;
                verified = data.data.verified;
            })
        );
    };

    onMount(async () => {
        getProfile();
    });

    if (verified == 0) {
        location.href = "/#/dashboard/verify";
    }

    loggedIn.subscribe((v) => {
        isLoggedIn = v;
        if (!v) {
            location.href = "/";
        }
    });

    username.subscribe((v) => {
        usernameValue = v;
    });

    uid.subscribe((v) => {
        uidValue = v;
    });
</script>

{#if isLoggedIn}
    <div>
        <header class="jst-container flex h-screen bg-hero bg-cover">
            <img
                src="https://cdn.discordapp.com/attachments/919533264119677018/1100115158283583488/20230424_194441_0000.png"
                alt=""
                class="absolute object-fill w-full h-screen"
            />
            <div class="mt-12 px-6 flex mx-auto h-[100vh] relative">
                <div class="items-center md:flex m-auto">
                    <div class="w-full">
                        <div
                            class="text-center space-y-4 items-center flex flex-col mx-auto justify-center"
                        >
                            <div class="flex justify-center gap-2">
                                <div
                                    class="flex w-full max-w-xs gap-2"
                                    style="marginTop: 8px "
                                >
                                    <a href="https://api.imgs.bar/auth/discord">
                                        <button
                                            class="mt-3 flex w-full items-center rounded-lg border border-[#5865F2] p-1 px-3 text-lg text-gray-200 transition-all hover:border-[#404EED] hover:bg-[#404EED]"
                                        >
                                            <div
                                                class="m-auto flex items-center"
                                            >
                                                <svg
                                                    xmlns="http://www.w3.org/2000/svg"
                                                    width="16"
                                                    height="16"
                                                    fill="currentColor"
                                                    class="mr-1"
                                                    viewBox="0 0 16 16"
                                                >
                                                    <path
                                                        d="M13.545 2.907a13.227 13.227 0 0 0-3.257-1.011.05.05 0 0 0-.052.025c-.141.25-.297.577-.406.833a12.19 12.19 0 0 0-3.658 0 8.258 8.258 0 0 0-.412-.833.051.051 0 0 0-.052-.025c-1.125.194-2.22.534-3.257 1.011a.041.041 0 0 0-.021.018C.356 6.024-.213 9.047.066 12.032c.001.014.01.028.021.037a13.276 13.276 0 0 0 3.995 2.02.05.05 0 0 0 .056-.019c.308-.42.582-.863.818-1.329a.05.05 0 0 0-.01-.059.051.051 0 0 0-.018-.011 8.875 8.875 0 0 1-1.248-.595.05.05 0 0 1-.02-.066.051.051 0 0 1 .015-.019c.084-.063.168-.129.248-.195a.05.05 0 0 1 .051-.007c2.619 1.196 5.454 1.196 8.041 0a.052.052 0 0 1 .053.007c.08.066.164.132.248.195a.051.051 0 0 1-.004.085 8.254 8.254 0 0 1-1.249.594.05.05 0 0 0-.03.03.052.052 0 0 0 .003.041c.24.465.515.909.817 1.329a.05.05 0 0 0 .056.019 13.235 13.235 0 0 0 4.001-2.02.049.049 0 0 0 .021-.037c.334-3.451-.559-6.449-2.366-9.106a.034.034 0 0 0-.02-.019Zm-8.198 7.307c-.789 0-1.438-.724-1.438-1.612 0-.889.637-1.613 1.438-1.613.807 0 1.45.73 1.438 1.613 0 .888-.637 1.612-1.438 1.612Zm5.316 0c-.788 0-1.438-.724-1.438-1.612 0-.889.637-1.613 1.438-1.613.807 0 1.451.73 1.438 1.613 0 .888-.631 1.612-1.438 1.612Z"
                                                    />
                                                </svg>
                                                Verify
                                            </div>
                                        </button>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
    </div>
{/if}
