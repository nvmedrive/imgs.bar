<script>
    import { blur } from "svelte/transition";
</script>

<div class="flex h-screen text-white">
    <div class="m-auto p-4">
        <p class="text-center text-3xl font-bold">Access denied</p>
        <p class="text-center">You can't view this page.</p>
    </div>
</div>
