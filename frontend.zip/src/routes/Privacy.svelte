<div class="flex min-h-screen justify-center p-2">
    <div class="m-auto w-full max-w-7xl rounded-lg bg-zinc-800 p-5">
        <h1 class="text-center text-2xl font-semibold text-white">Privacy Policy</h1>
        <p class="text-center text-white">imgs.bar & imgs.bio privacy policy (Last updated May 30th, 2023)</p>
        <div class="ml-4 mt-8 grid gap-4 text-2xl font-medium text-gray-300">
            <div>
                <div>
                    <li>Registration.</li>
                    <p>After your registration imgs.bar will store your email, username, hashed password, date of registry and hashed ip adress</p>
                </div>
                <div>
                    <li>Login.</li>
                    <p>After your login at imgs.bar your session cookie and hashed ip are saved.</p>
                </div>
                <div>
                    <li>Discord.</li>
                    <p>When you link your discord account to imgs.bar we store your discord id, profile picture and username + tag. You are also put into the imgs.bar discord server and you will recive automaticly the member role.</p>
                </div>
                <div>
                    <li>Third Apps</li>
                    <p>We use Cloudflare and discord as a third party provider. In both cases, the privacy policy of the corresponding apps also apply.</p>
                </div>
                <div>
                    <li>Where your data is stored.</li>
                    <p>Your private data is stored on a server in Frankfurt Germany and your files are stored in Dublin Ireland.</p>
                </div>
                <div>
                    <li>Underaged Users.</li>
                    <p>Underaged users(13) are not allowed to use imgs.bar. If we find out that you are underaged, we will delete your account and all your data.</p>
                </div>
                <div>
                    <li>Policy update</li>
                    <p>We can update our policy at any time.</p>
                </div>
            </div>
        </div>
</div>
</div>
