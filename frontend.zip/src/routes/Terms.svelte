<div class="flex min-h-screen justify-center p-2">
    <div class="m-auto w-full max-w-7xl rounded-lg bg-zinc-800 p-5">
        <h1 class="text-center text-2xl font-semibold text-white">
            Terms of Service
        </h1>
        <p class="text-center text-white">
            By using imgs.bar, you agree to the following terms of service:
        </p>
        <div class="ml-4 mt-8 grid gap-4 text-2xl font-medium text-gray-300">
            <div>
                <div>
                    <li>No creating multi accounts.</li>
                </div>
                <div>
                    <li>You will not spam.</li>
                </div>
                <div>
                    <li>You will not impersonate other users.</li>
                </div>
                <div>
                    <li>You will not post illegal content.</li>
                </div>
                <div>
                    <li>You will not harass other users.</li>
                </div>
                <div>
                    <li>You will not dox other users.</li>
                </div>
                <div>
                    <li>You will not threaten other users.</li>
                </div>
                <div>
                    <li>You will not post hate speech.</li>
                </div>
                <div>
                    <li>You will not post NSFW content under 18.</li>
                </div>
            </div>
        </div>
    </div>
</div>
