<script>
    import Response from "../components/Response.svelte";
    import { ArrowLeftIcon } from "svelte-feather-icons";
    import axios from "axios";
    import { onMount } from "svelte";
    import { loggedIn } from "../stores";

    let form = {};
    let response = {};
    let captchaImage = "";
    let captchaCode = "";
    let captchaInput = "";

    loggedIn.subscribe((v) => {
        if (v) {
            location.href = "/#/dashboard";
        }
    });

    onMount(async () => {
        await axios.get(`https://api.imgs.bar/status/invite`).then((res) => {
            response = {
                status: res.status,
                inviteOnly: res.data.inviteOnly,
            };
        });
        console.log(response);
    });

    async function register() {
        // Verify the captcha code
        if (captchaInput.toLowerCase() !== captchaCode.toLowerCase()) {
            response = {
                status: 400,
                message: "Invalid CAPTCHA code",
            };
            return;
        }

        await axios({
            withCredentials: true,
            method: "post",
            url: "https://api.imgs.bar/auth/register",
            data: form,
        }).then((res) => {
            response.status = res.status;
            response.message = res.data.message;
        });

        if (response.status === 200) {
            location.href = "#/dashboard";
        }
    }

    function generateCaptcha() {
        const characters =
            "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        let code = "";
        for (let i = 0; i < 6; i++) {
            code += characters.charAt(
                Math.floor(Math.random() * characters.length)
            );
        }
        captchaCode = code;

        // Request the CAPTCHA image from the server
        axios
            .get(`https://api.imgs.bar/utils/captcha?code=${captchaCode}`, { responseType: 'blob' })
            .then((res) => {
                const blob = new Blob([res.data], { type: "image/png" });
                captchaImage = URL.createObjectURL(blob);
            });
    }


    onMount(() => {
        generateCaptcha();
    });
</script>

<section class="bg-backimg absolute object-fill w-full h-screen">
    <div
        class="flex flex-col items-center justify-center px-6 py-8 mx-auto md:h-screen lg:py-0"
    >
        <div
            class="w-full rounded-lg shadow border md:mt-0 sm:max-w-md xl:p-0 bg-zinc-900 border-zinc-800"
        >
            <div class="p-6 space-y-4 md:space-y-6 sm:p-8">
                <h1 class="text-xl font-bold md:text-2xl text-white">
                    Welcome!
                </h1>
                <p class="text-sm text-gray-400">Register to get an account!</p>
                <form
                    class="space-y-4 md:space-y-6"
                    id="register"
                    on:submit|preventDefault={register}
                >
                    {#if response.message != undefined}
                        <Response
                            status={response.status}
                            message={response.message}
                        />
                    {/if}
                    <div>
                        <label
                            for="username"
                            class="block mb-2 text-sm font-medium text-white"
                            >Username</label
                        >
                        <input
                            type="text"
                            name="username"
                            id="username"
                            bind:value={form.username}
                            placeholder="Username"
                            class="border sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 bg-gray-700 border-gray-600 placeholder-gray-400 text-white focus:ring-blue-500 focus:border-blue-500"
                            required
                        />
                    </div>
                    <div>
                        <label
                            for="email"
                            class="block mb-2 text-sm font-medium text-white"
                            >E-Mail</label
                        >
                        <input
                            type="email"
                            name="email"
                            id="email"
                            bind:value={form.email}
                            placeholder="user@imgs.bar"
                            class="border sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 bg-gray-700 border-gray-600 placeholder-gray-400 text-white focus:ring-blue-500 focus:border-blue-500"
                            required
                        />
                    </div>
                    <div>
                        <label
                            for="password"
                            class="block mb-2 text-sm font-medium text-white"
                            >Password</label
                        >
                        <input
                            type="password"
                            name="password"
                            id="password"
                            bind:value={form.password}
                            placeholder="••••••••"
                            class="border sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 bg-gray-700 border-gray-600 placeholder-gray-400 text-white focus:ring-blue-500 focus:border-blue-500"
                            required
                        />
                    </div>
                    {#if response.inviteOnly}
                        <div>
                            <label
                                for="invite"
                                class="block mb-2 text-sm font-medium text-white"
                                >Invite Code</label
                            >
                            <input
                                type="text"
                                name="invite"
                                id="invite"
                                bind:value={form.invite}
                                placeholder="IMGS-BAR-INVITE-123"
                                class="border sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 bg-gray-700 border-gray-600 placeholder-gray-400 text-white focus:ring-blue-500 focus:border-blue-500"
                                required
                            />
                        </div>
                    {/if}
                    <div>
                        <div class="flex items-center justify-between">
                            <label
                                for="captcha"
                                class="block mb-2 text-sm font-medium text-white"
                                >Enter the CAPTCHA code:</label
                            >
                            <button
                                type="button"
                                class="text-gray-400 hover:text-gray-300 focus:outline-none focus:text-gray-500"
                                on:click={generateCaptcha}
                            >
                                Refresh CAPTCHA
                            </button>
                        </div>
                        <div class="flex items-center">
                            <input
                                type="text"
                                name="captcha"
                                id="captcha"
                                bind:value={captchaInput}
                                placeholder="Enter the CAPTCHA code"
                                class="border sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 bg-gray-700 border-gray-600 placeholder-gray-400 text-white focus:ring-blue-500 focus:border-blue-500"
                                required
                            /><br /><br /><br />
                            <img src={captchaImage} alt="CAPTCHA Image" />
                        </div>
                    </div>
                    <button
                        type="submit"
                        class="w-full text-white bg-blue-600 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center"
                    >
                        Sign up
                    </button>
                </form>
                <p class="text-sm font-light text-gray-400">
                    Already have an account?
                    <a
                        href="/#/login"
                        class="font-medium text-primary-600 hover:underline text-primary-500"
                        >Login</a
                    >
                </p>
            </div>
        </div>
    </div>
</section>
