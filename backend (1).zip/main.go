package main

import (
	"github.com/gofiber/fiber/v2/middleware/cors"
	"github.com/joho/godotenv"

	"github.com/upload-wtf/backend/database"

	"github.com/upload-wtf/backend/buck"
	"github.com/upload-wtf/backend/configs"
	"github.com/upload-wtf/backend/router"
)

var UnauthorizedErr = "you don't have permission to perform this action"

func main() {

	// fiber configuration
	app := configs.FiberApp
	app.Use(cors.New(cors.Config{AllowCredentials: true}))
	// app.Use(cors.New(cors.Config{
	// 	AllowOrigins: "https://imgs.bar, https://www.imgs.bar, https://upload.wtf, http://localhost:5173",
	// 	AllowHeaders: "Origin, Content-Type, Accept",
	// 	AllowMethods: "GET, POST, PUT, DELETE",
	// 	})
	// )

	// loading .env
	err := godotenv.Load()
	if err != nil {
		panic("Error loading .env file")
	}

	// database connection
	database.Connect()

	// bucket start
	buck.Start()

	// router
	router.ConnectRouter(app)

	// app run on port 4000
	app.Listen(":4000")

}
