package lib

import (
	"fmt"
	"net/http"
	"os"
	"time"

	"github.com/gtuk/discordwebhook"
	"github.com/upload-wtf/backend/database"
)

func CheckDomains() {
	client := &http.Client{
		Timeout: 10 * time.Second,
	}

	for {
		domains, err := database.GetDomainsCF()
		if err != nil {
			continue
		}

		for _, domain := range domains {
			resp, err := client.Get("https://" + domain)
			if err != nil {
				continue
			}

			// print the HTTP status
			fmt.Println(resp.Status)

			defer resp.Body.Close()

			if resp.StatusCode != http.StatusOK {
				title := "Domain Removed"
				description := domain + " was removed from upload.wtf"
				footer := "upload.wtf"
				footerobj := discordwebhook.Footer{
					Text: &footer,
				}
				color := "#fc0303"
				message := discordwebhook.Message{
					Embeds: &[]discordwebhook.Embed{{
						Title:       &title,
						Description: &description,
						Footer:      &footerobj,
						Color:       &color,
					}},
				}
				discordwebhook.SendMessage(os.Getenv("DOMAINS_WEBHOOK_URL"), message)
			}
		}

		time.Sleep(5 * time.Minute)
	}
}
