package lib

import (
	"sync"
	"time"
)

type RateLimiter struct {
	uidMap  map[string]*TokenBucket
	timeout time.Duration
	mutex   sync.Mutex
}

type TokenBucket struct {
	tokens      int
	lastRefill  time.Time
	refillRate  float64
	maxCapacity int
}

func NewRateLimiter(capacity int, duration time.Duration) *RateLimiter {
	return &RateLimiter{
		uidMap:  make(map[string]*TokenBucket),
		timeout: duration,
		mutex:   sync.Mutex{},
	}
}

func (rl *RateLimiter) Allow(uid string) bool {
	rl.mutex.Lock()
	defer rl.mutex.Unlock()

	tb, exists := rl.uidMap[uid]
	now := time.Now()

	if !exists {
		tb = &TokenBucket{
			tokens:      0,
			lastRefill:  now,
			refillRate:  float64(tb.maxCapacity) / rl.timeout.Seconds(),
			maxCapacity: 2,
		}
		rl.uidMap[uid] = tb
	}

	// Refill tokens
	elapsed := now.Sub(tb.lastRefill)
	tb.tokens += int(elapsed.Seconds() * tb.refillRate)
	tb.lastRefill = now

	if tb.tokens > tb.maxCapacity {
		tb.tokens = tb.maxCapacity
	}

	if tb.tokens > 0 {
		tb.tokens--
		return true
	}

	return false
}
