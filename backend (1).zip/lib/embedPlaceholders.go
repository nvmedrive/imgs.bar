package lib

import (
	"fmt"
	"strings"
	"time"

	"github.com/upload-wtf/backend/database"
	"github.com/upload-wtf/backend/model"
)

func EmbedPlaceholders(site_name string, site_name_url string, title string, description string, author string, author_url string, token string, fileSize int64, fileName string, delay time.Duration) model.EmbedStruct {
	var placeholders [6]string

	placeholders[0] = "$user$"
	placeholders[1] = "$uploads$"
	placeholders[2] = "$delay$"
	placeholders[3] = "$size$"
	placeholders[4] = "$filename$"
	placeholders[5] = "$uid$"
//	placeholders[6] = "$discord$"
	uploadCounter, _ := database.GetUploadCounter(token)
	userClaims := database.VerifyUser(token)

	var values [6]any
	values[0] = userClaims.Username
	values[1] = uploadCounter + 1 // plus one counting this upload
	values[2] = delay
	values[3] = fileSize
	values[4] = fileName
	values[5] = userClaims.Uid
//	values[6] = userClaims.Discord

	substituteValue := func(str string) string {
		newStr := str
		for i := 0; len(placeholders) > i; i++ {
			placeholder := placeholders[i]
			value := values[i]
			newStr = strings.ReplaceAll(newStr, placeholder, fmt.Sprintf("%v", value))
		}
		return newStr
	}

	new_site_name := substituteValue(site_name)
	new_title := substituteValue(title)
	new_description := substituteValue(description)
	new_author := substituteValue(author)
	return model.EmbedStruct{Title: new_title, Description: new_description, Author: new_author, SiteName: new_site_name, SiteNameUrl: site_name_url, AuthorUrl: author_url}
}
