package bio

import (
	"fmt"

	"github.com/gofiber/fiber/v2"
	"github.com/upload-wtf/backend/database"
)

func RenderBio(c *fiber.Ctx) error {

	username := c.Params("user")
	fmt.Println(username)
	bio, err := database.GetBio(username)
	if err != nil {
		return c.Status(404).JSON(fiber.Map{"error": true, "message": "This bio don't exist"})
	}
	return c.Status(fiber.StatusOK).JSON(fiber.Map{"error": false, "message": "Success", "data": bio})

}
