package files

import (

	"encoding/json"
    "log"
    "time"

	"github.com/gofiber/fiber/v2"
    "github.com/bensch777/discord-webhook-golang"
)

type ParseReportQuery struct {
	Reporter_Username string `json:"reporter_username" xml:"reporter_username"`
	File_ID 		  string `json:"file_id" xml:"ile_id"`
}

func ReportFile(c *fiber.Ctx) error {
	parser := new(ParseReportQuery)
	if err := c.BodyParser(parser); err != nil {
		return err
	}
	
    var webhookurl = "https://discordapp.com/api/webhooks/1099649363346718770/FjBaHNuiSLsmyibl5_i3ofv0PKnGC5tlOl-Rn9z8Y-ozW4zADF31Aij_KKyyxurSbqZT"

    embed := discordwebhook.Embed{
        Title:     "Upload-WTF Reports",
        Color:     15277667,
        Url:       "https://cdn.discordapp.com/attachments/919533264119677018/1099389902879195368/Picsart_23-04-22_19-42-49-464.png",
        Timestamp: time.Now(),
        Thumbnail: discordwebhook.Thumbnail{
            Url: "https://cdn.discordapp.com/attachments/919533264119677018/1099389902879195368/Picsart_23-04-22_19-42-49-464.png",
        },
        Author: discordwebhook.Author{
            Name:     "Report",
            Icon_URL: "https://cdn.discordapp.com/attachments/919533264119677018/1099389902879195368/Picsart_23-04-22_19-42-49-464.png",
        },
        Fields: []discordwebhook.Field{
            discordwebhook.Field{
                Name:   "Reported File",
                Value:  parser.File_ID,
                Inline: true,
            },
            discordwebhook.Field{
                Name:   "Url",
                Value:  "https://i.upload.wtf/" + parser.File_ID,
                Inline: true,
            },
			discordwebhook.Field{
                Name:   "Reported by",
                Value:  parser.Reporter_Username,
                Inline: false,
            },
        },
        Footer: discordwebhook.Footer{
            Text:     "Reported by " + parser.Reporter_Username,
            Icon_url: "https://cdn.discordapp.com/attachments/919533264119677018/1099389902879195368/Picsart_23-04-22_19-42-49-464.png",
        },
    }

    SendEmbed(webhookurl, embed)

	return c.Status(fiber.StatusOK).JSON(fiber.Map{"error": false, "message": "reported."})

}

func SendEmbed(link string, embeds discordwebhook.Embed) error {

    hook := discordwebhook.Hook{
        Username:   "Upload-WTF Reports",
        Avatar_url: "https://cdn.discordapp.com/attachments/919533264119677018/1099389902879195368/Picsart_23-04-22_19-42-49-464.png",
        Content:    "",
        Embeds:     []discordwebhook.Embed{embeds},
    }

    payload, err := json.Marshal(hook)
    if err != nil {
        log.Fatal(err)
    }
    err = discordwebhook.ExecuteWebhook(link, payload)
    return err

}