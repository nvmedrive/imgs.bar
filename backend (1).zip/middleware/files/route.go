package files

import (
	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/limiter"
)

var rateLimiter = limiter.New(limiter.Config{
	Max:        2,
	Expiration: 4,
})

func Routes(router fiber.Router) {

	group := router.Group("/")

	// group.Post("/", Upload)
	// ratelimiter with ip check
	group.Post("/", rateLimiter, Upload)
	group.Get("/render/:id", Render)
	group.Delete("/:file", DeleteFile)
	group.Get("/embed", RenderEmbed)
	group.Post("/report", ReportFile)
}
