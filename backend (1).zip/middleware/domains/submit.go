package domains

// TODO: Rewrite
