package admin

import (
	"os"
	"strconv"

	"github.com/upload-wtf/backend/database"
	"github.com/upload-wtf/backend/handler"
	"github.com/gofiber/fiber/v2"
)

func InviteWave(c *fiber.Ctx) error {
	token := c.Cookies("token")
	if invite, _ := strconv.ParseBool(os.Getenv("INVITE_ONLY")); !invite {
		return c.Status(fiber.StatusNotImplemented).JSON(fiber.Map{"error": true, "message": "Invite system isn't enabled"})
	}
	err := database.InviteWave(token)

	if err != nil {
		status, errString := handler.Errors(err)
		return c.Status(status).JSON(fiber.Map{"error": true, "message": errString})
	}
	return c.Status(fiber.StatusOK).JSON(fiber.Map{"error": false, "message": "Success"})
}
