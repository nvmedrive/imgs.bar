package profile

import (
	"fmt"

	"github.com/gofiber/fiber/v2"
	"github.com/upload-wtf/backend/database"
)

func GetByDc(c *fiber.Ctx) error {

	user := c.Params("dc")
	fmt.Println(user)
	userdata, err := database.GetProfileByDc(user)
	if err != nil {
		return c.Status(404).JSON(fiber.Map{"error": false, "message": "This user don't exist"})
	}
	return c.Status(fiber.StatusOK).JSON(fiber.Map{"error": false, "message": "Success", "data": userdata})

}

