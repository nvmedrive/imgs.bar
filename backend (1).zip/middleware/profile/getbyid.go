package profile

import (
	"fmt"

	"github.com/gofiber/fiber/v2"
	"github.com/upload-wtf/backend/database"
)

func GetById(c *fiber.Ctx) error {

	user := c.Params("id")
	fmt.Println(user)
	userdata, err := database.GetProfileById(user)
	if err != nil {
		return c.Status(404).JSON(fiber.Map{"error": false, "message": "This user don't exist"})
	}
	return c.Status(fiber.StatusOK).JSON(fiber.Map{"error": false, "message": "Success", "data": userdata})

}
