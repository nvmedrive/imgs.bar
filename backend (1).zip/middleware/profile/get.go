package profile

import (
	"fmt"

	"github.com/upload-wtf/backend/database"
	"github.com/gofiber/fiber/v2"
)

func GetData(c *fiber.Ctx) error {

	user := c.Params("user")
	fmt.Println(user)
	userdata, err := database.GetProfile(user)
	if err != nil {
		return c.Status(404).JSON(fiber.Map{"error": false, "message": "This user don't exist"})
	}
	return c.Status(fiber.StatusOK).JSON(fiber.Map{"error": false, "message": "Success", "data": userdata})

}