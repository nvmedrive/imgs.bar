package bot

import (
	"github.com/gofiber/fiber/v2"
)

func Routes(router fiber.Router) {
	group := router.Group("/")

	group.Post("/wave", BotWave)
	group.Post("/giveinv", BotGiveInv)
	group.Post("/blacklist", BlacklistUser)
	group.Post("/unblacklist", BUnblacklistUser)
}

