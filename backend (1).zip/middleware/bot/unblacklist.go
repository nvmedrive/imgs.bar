package bot

import (
	"os"

	"github.com/gofiber/fiber/v2"
	"github.com/upload-wtf/backend/database"
	"github.com/upload-wtf/backend/handler"
)

type reqq struct {
	Token    string `json:"token" xml:"token"`
	Username string `json:"username" xml:"username"`
}

func BUnblacklistUser(c *fiber.Ctx) error {

	parser := new(reqq)
	if err := c.BodyParser(parser); err != nil {
		return err
	}

	if os.Getenv("TOKEN") != parser.Token {
		return c.Status(fiber.StatusUnauthorized).JSON(fiber.Map{"error": true, "message": "Something went wrong contact the developer"})
	}

	err := database.BotUnblacklistUser(parser.Token, parser.Username)

	if err != nil {
		status, errString := handler.Errors(err)
		return c.Status(status).JSON(fiber.Map{"error": true, "message": errString})
	}

	return c.Status(fiber.StatusOK).JSON(fiber.Map{"error": false, "message": "Success"})
}
