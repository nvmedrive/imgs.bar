package bot

import (
	"os"
	"strconv"

	"github.com/gofiber/fiber/v2"
	"github.com/upload-wtf/backend/database"
	"github.com/upload-wtf/backend/handler"
)

type Req struct {
	Token string `json:"token" xml:"token"`
}

func BotWave(c *fiber.Ctx) error {
	parser := new(Req)
	if err := c.BodyParser(parser); err != nil {
		return err
	}

	if os.Getenv("TOKEN") != parser.Token {
		return c.Status(fiber.StatusUnauthorized).JSON(fiber.Map{"error": true, "message": "Something went wrong contact the developer"})
	}

	if invite, _ := strconv.ParseBool(os.Getenv("INVITE_ONLY")); !invite {
		return c.Status(fiber.StatusNotImplemented).JSON(fiber.Map{"error": true, "message": "Invite system isn't enabled"})
	}
	err := database.BotInviteWave(parser.Token)

	if err != nil {
		status, errString := handler.Errors(err)
		return c.Status(status).JSON(fiber.Map{"error": true, "message": errString})
	}
	return c.Status(fiber.StatusOK).JSON(fiber.Map{"error": false, "message": "Success"})
}
