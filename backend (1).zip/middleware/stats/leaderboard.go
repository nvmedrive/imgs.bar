package stats

import (
	"github.com/gofiber/fiber/v2"
	"github.com/upload-wtf/backend/database"
)

func GetLeaderboard(c *fiber.Ctx) error {

	stats, err := database.GetLeaderboard()
	if err != nil {
		return c.Status(404).JSON(fiber.Map{"error": false, "message": "Something went wrong"})
	}

	return c.Status(fiber.StatusOK).JSON(fiber.Map{"error": false, "message": "Success", "data": stats})

}

// func GetLeaderboard() ([]map[string]any, error) {
// 	db := DB

// 	result := []map[string]any{}
// 	db.Raw("SELECT username, COUNT(*) FROM uploads LEFT JOIN users ON uploads.user_id = users.id GROUP BY username ORDER BY COUNT(*) DESC LIMIT 10").Find(&result)
// 	if len(result) == 0 {
// 		return nil, errors.New("failed to get leaderboard")
// 	}
// 	return result, nil
// }
