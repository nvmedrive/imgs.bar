package stats

import (
	// fiber
	"github.com/gofiber/fiber/v2"
)

func test(c *fiber.Ctx) error {
	// get ip, user-agent and print it
	ip := c.IP()
	ua := c.Get("User-Agent")
	// return json
	return c.JSON(fiber.Map{
		"ip": ip,
		"ua": ua,
	})
}
