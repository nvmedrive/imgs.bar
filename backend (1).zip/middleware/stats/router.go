package stats

import (
	"github.com/gofiber/fiber/v2"
)

func Routes(router fiber.Router) {
	group := router.Group("/")

	group.Get("stats", GetStats)
	group.Get("domains", GetDomains)
	group.Get("leaderboard", GetLeaderboard)
	group.Get("blacklisted", GetBlacklisted)
	group.Get("test", test)
}

