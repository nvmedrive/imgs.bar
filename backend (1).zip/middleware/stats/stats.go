package stats

import (
	"github.com/gofiber/fiber/v2"
	"github.com/upload-wtf/backend/database"

	"context"

	"github.com/minio/minio-go/v7"
	"github.com/upload-wtf/backend/buck"
	"github.com/upload-wtf/backend/handler"
)

func GetStats(c *fiber.Ctx) error {

	stats, err := database.GetStats()
	if err != nil {
		return c.Status(404).JSON(fiber.Map{"error": false, "message": "Something went wrong"})
	}

	// get the minio bucket "files" used storage
	bucket := buck.Bucket
	objects := bucket.ListObjects(context.Background(), "files", minio.ListObjectsOptions{})
	var size int64
	for object := range objects {
		if object.Err != nil {
			status, _ := handler.Errors(object.Err)
			return c.Status(status).JSON(fiber.Map{"error": true, "message": "something unexpected happened; contact an admin"})
		}
		size += object.Size

	}

	// add the used storage to the stats

	// return the stats and the used storage together in a json response
	return c.Status(200).JSON(fiber.Map{"error": false, "message": "success", "stats": stats})

}
