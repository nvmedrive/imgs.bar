package stats

import (
	"github.com/gofiber/fiber/v2"
	"github.com/upload-wtf/backend/database"
)

func GetBlacklisted(c *fiber.Ctx) error {

	stats, err := database.GetBlacklisted()
	if err != nil {
		return c.Status(404).JSON(fiber.Map{"error": false, "message": "Something went wrong"})
	}

	return c.Status(fiber.StatusOK).JSON(fiber.Map{"error": false, "message": "Success", "data": stats})

}
