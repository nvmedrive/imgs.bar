package stats

import (
	"github.com/gofiber/fiber/v2"
	"github.com/upload-wtf/backend/database"
)

// func GetDomainsCF() ([]string, error) {
// 	db := DB

// 	var domains []struct {
// 		Domain string
// 	}

// 	// db raw
// 	db.Raw("SELECT domain FROM domains").Scan(&domains)

// 	// if err := db.Select("domain").Find(&domains).Error; err != nil {
// 	// 	return nil, err
// 	// }

// 	result := make([]string, len(domains))
// 	for i, d := range domains {
// 		result[i] = d.Domain
// 	}

// 	return result, nil
// }

func GetDomains(c *fiber.Ctx) error {

	stats, err := database.GetDomainsCF()
	if err != nil {
		return c.Status(404).JSON(fiber.Map{"error": false, "message": "Something went wrong"})
	}

	// return every domain
	return c.Status(fiber.StatusOK).JSON(fiber.Map{"error": false, "message": "Success", "data": stats})

}
