package preferences

import (
	"fmt"

	"github.com/gofiber/fiber/v2"
	"github.com/upload-wtf/backend/database"
)

func GetConfig(c *fiber.Ctx) error {

	token := c.Cookies("token")
	cftype := c.Params("type")

	userClaims := database.VerifyUser(token)
	if !userClaims.ValidUser || userClaims.Blacklisted {
		return c.Status(fiber.StatusUnauthorized).JSON(fiber.Map{"error": true, "message": "you don't have permission to perform this action"})
	}

	if cftype == "sharex" {
		config := fmt.Sprintf(`{
		"Version": "14.0.0",
		"Name": "imgs.bar",
		"DestinationType": "ImageUploader, FileUploader",
		"RequestMethod": "POST",
		"RequestURL": "https://api.imgs.bar/files",
		"Headers": {
		  "Authorization": "%s",
		},
		"Body": "MultipartFormData",
		"FileFormName": "file",
		"URL": "{json:url}",
		"ThumbnailURL": "{json:file_url}",
		"ErrorMessage": "{json:error}"
	  }`, userClaims.ApiKey)

		return c.Status(200).JSON(fiber.Map{"error": false, "message": "success", "config": config})
	} else if cftype == "flameshot" {
		config := fmt.Sprintf(`
		#!/bin/bash

temp_file="/tmp/screenshot.png"
flameshot gui -r > "$temp_file"

if ! file --mime-type -b "$temp_file" | grep -q "image/png"; then
    rm "$temp_file"
    notify-send "Screenshot aborted" -a "imgs.bar" && exit 1
fi

response=$(curl -H "Authorization: %s" -X POST -F "file=@$temp_file" "https://api.imgs.bar/files")

if echo "$response" | jq -e '.error == "invalid upload secret"' >/dev/null; then
    notify-send "Invalid upload secret. Please check the Flameshot config file." -a "upload.wtf" && exit 1
fi

url=$(echo "$response" | jq -r '.url')
thumbnail=$(echo "$response" | jq -r '.file_url')
notify-send "Image Uploaded" "$url" -a "imgs.bar" -i "$temp_file"
rm "$temp_file"
		`, userClaims.ApiKey)

		return c.Status(200).JSON(fiber.Map{"error": false, "message": "success", "config": config})
	}

	return c.Status(400).JSON(fiber.Map{"error": true, "message": "invalid type"})
}
