package preferences

import (
//	"github.com/goccy/go-json"
	"github.com/gofiber/fiber/v2"
//	"github.com/upload-wtf/backend/handler"
)

func GetUploadKey(c *fiber.Ctx) error {

	return nil

}
