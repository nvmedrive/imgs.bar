package preferences

import (
	"github.com/gofiber/fiber/v2"
	"github.com/upload-wtf/backend/database"
	"github.com/upload-wtf/backend/handler"
)

type Request struct {
	Domain string `json:"domain" xml:"domain"`
	Sub    string `json:"subdomain" xml:"subdomain"`
}

func ChangeDomain(c *fiber.Ctx) error {

	token := c.Cookies("token")

	parser := new(Request)
	if err := c.BodyParser(parser); err != nil {
		return err
	}

	if parser.Sub != "" {
		err := database.UpdateDomainSubDomain(token, parser.Domain, parser.Sub)
		if err != nil {
			status, errMsg := handler.Errors(err)
			return c.Status(status).JSON(fiber.Map{"error": true, "message": errMsg})
		}

	} else {
		err := database.UpdateDomain(token, parser.Domain)
		if err != nil {
			status, errMsg := handler.Errors(err)
			return c.Status(status).JSON(fiber.Map{"error": true, "message": errMsg})
		}
	}

	return c.Status(fiber.StatusOK).JSON(fiber.Map{"error": false, "message": "success"})
}


