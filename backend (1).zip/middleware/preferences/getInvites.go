package preferences

import (
	"github.com/upload-wtf/backend/database"
	"github.com/upload-wtf/backend/handler"
	"github.com/gofiber/fiber/v2"
)

func GetInvites(c *fiber.Ctx) error {
	token := c.Cookies("token")

	invites, err := database.GetInvites(token)

	if err != nil {
		status, errMsg := handler.Errors(err)
		return c.Status(status).JSON(fiber.Map{"error": true, "message": errMsg})
	}

	return c.Status(fiber.StatusOK).JSON(fiber.Map{"error": false, "message": "Success", "invites": invites})
}
