package preferences

import (
	"github.com/gofiber/fiber/v2"
	"github.com/upload-wtf/backend/database"
	"github.com/upload-wtf/backend/handler"
)

type RequestBio struct {
	DiscordRpc      bool   `json:"discordrpc" xml:"discordrpc"`
	BackgroundUrl   string `json:"backgroundurl" xml:"backgroundurl"`
	EmbedDescripton string `json:"embeddesc" xml:"embeddesc"`
	EmbedColor      string `json:"embedcolor" xml:"embedcolor"`
	LogoUrl         string `json:"logourl" xml:"logourl"`
	Description     string `json:"description" xml:"description"`
	Youtube         string `json:"youtube" xml:"youtube"`
	Reddit          string `json:"reddit" xml:"reddit"`
	Twitch          string `json:"twitch" xml:"twitch"`
	Pinterest       string `json:"pinterest" xml:"pinterest"`
	Linkedin        string `json:"linkedin" xml:"linkedin"`
	GitHub          string `json:"github" xml:"github"`
	PayPal          string `json:"paypal" xml:"paypal"`
}

func ChangeBioSettings(c *fiber.Ctx) error {
	parser := new(RequestBio)
	if err := c.BodyParser(parser); err != nil {
		return err
	}

	token := c.Cookies("token")

	err := database.UpdateBio(token, parser.DiscordRpc, parser.BackgroundUrl, parser.EmbedDescripton, parser.EmbedColor, parser.LogoUrl, parser.Description, parser.Youtube, parser.Reddit, parser.Twitch, parser.Pinterest, parser.Linkedin, parser.GitHub, parser.PayPal)

	if err != nil {
		status, errMsg := handler.Errors(err)
		return c.Status(status).JSON(fiber.Map{"error": true, "message": errMsg})
	}

	return c.Status(fiber.StatusOK).JSON(fiber.Map{"error": false, "message": "Success"})
}
