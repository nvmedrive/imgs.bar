package preferences

import (
	"github.com/gofiber/fiber/v2"
)

func Routes(router fiber.Router) {
	change := router.Group("/change")
	get := router.Group("/get")
	del := router.Group("/delete")

	change.Post("/domain", ChangeDomain)
	get.Get("/domain", GetDomain)

	change.Post("/bio", ChangeBioSettings)

	change.Post("/embed", ChangeEmbed)
	get.Get("/embed", GetEmbed)

	get.Get("/domains", GetDomains)

	get.Get("/apiKey", GetUploadKey)

	change.Post("/password", ChangePassword)

	get.Get("/uploads", GetUploads)

	get.Get("/config/:type", GetConfig)

	get.Get("/invites", GetInvites)

	get.Get("/profile", getPrvProfile)
	change.Post("/profile", ChangePublicProfile)

	get.Get("/lastUploads", GetLastUploads)

	change.Post("/path", ChangePath)

	del.Post("/deleteAcc", DelAcc)
}
