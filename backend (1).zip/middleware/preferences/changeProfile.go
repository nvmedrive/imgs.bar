package preferences

import (
	"github.com/gofiber/fiber/v2"
	"github.com/upload-wtf/backend/database"
	"github.com/upload-wtf/backend/handler"
)

type Reqs struct {
	ShowUploads      bool `json:"show_uploads" xml:"show_uploads"`
	ShowCreationDate bool `json:"show_creation_date" xml:"show_creation_date"`
	ShowDiscord      bool `json:"show_discord" xml:"show_discord"`
}

func ChangePublicProfile(c *fiber.Ctx) error {
	parser := new(Reqs)
	if err := c.BodyParser(parser); err != nil {
		return err
	}

	token := c.Cookies("token")

	err := database.UpdatePublicProfile(token, parser.ShowUploads, parser.ShowCreationDate, parser.ShowDiscord)

	if err != nil {
		status, errMsg := handler.Errors(err)
		return c.Status(status).JSON(fiber.Map{"error": true, "message": errMsg})
	}

	return c.Status(fiber.StatusOK).JSON(fiber.Map{"error": false, "message": "Success"})
}
