package auth

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"os"

	"github.com/clynt707/discord-oauth2"
	"github.com/gofiber/fiber/v2"
	"github.com/upload-wtf/backend/database"
	"golang.org/x/oauth2"
)

type DiscordUser struct {
	ID       string `json:"id"`
	Username string `json:"username"`
	Discrim  string `json:"discriminator"`
	Avatar   string `json:"avatar"`
}

func Callback(c *fiber.Ctx) error {
	conf := &oauth2.Config{
		Endpoint:     discord.Endpoint,
		Scopes:       []string{discord.ScopeIdentify, discord.ScopeGuilds, discord.ScopeEmail, discord.ScopeGuildsJoin},
		RedirectURL:  "https://api.imgs.bar/auth/callback",
		ClientID:     os.Getenv("CLIENT_ID"),
		ClientSecret: os.Getenv("CLIENT_SECRET"),
	}

	if c.FormValue("state") != state {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": true, "message": "State does not match."})
	}

	Authtoken := c.Cookies("token")

	token, err := conf.Exchange(c.Context(), c.FormValue("code"))
	if err != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": true, "message": err.Error()})
	}

	res, err := conf.Client(c.Context(), token).Get("https://discord.com/api/users/@me")
	if err != nil || res.StatusCode != 200 {
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": true, "message": err.Error()})
	}

	defer res.Body.Close()

	body, err := ioutil.ReadAll(res.Body)
	if err != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": true, "message": err.Error()})
	}

	responseString := string(body)

	var user DiscordUser
	err = json.Unmarshal([]byte(responseString), &user)
	if err != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": true, "message": "Failed to parse Discord user data."})
	}

	id := user.ID
	avatarURL := fmt.Sprintf("https://cdn.discordapp.com/avatars/%s/%s.png", id, user.Avatar)

	err = database.UpdateDiscord(Authtoken, user.ID, user.Username+"#"+user.Discrim, avatarURL)
	if err != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": true, "message": err.Error()})
	}

	err = addUserToServer(token.AccessToken, user.ID, os.Getenv("GUILD_ID"), c)
	if err != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"error": true, "message": err.Error()})
	}

	return c.Redirect("https://imgs.bar/#/dashboard", fiber.StatusTemporaryRedirect)
}

func addUserToServer(accessToken, userId, guildId string, c *fiber.Ctx) error {
	url := fmt.Sprintf("https://discord.com/api/guilds/%s/members/%s", guildId, userId)

	roles := []string{os.Getenv("ROLE_ID")}

	data := map[string]interface{}{
		"access_token": accessToken,
		"roles":        roles,
	}

	jsonData, err := json.Marshal(data)
	if err != nil {
		return err
	}

	req, err := http.NewRequest("PUT", url, bytes.NewBuffer(jsonData))
	if err != nil {
		return err
	}

	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Authorization", "Bot "+os.Getenv("BOT_TOKEN"))

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return err
	}

	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return c.Redirect("https://imgs.bar/#/dashboard", fiber.StatusTemporaryRedirect)
	}

	return nil
}
