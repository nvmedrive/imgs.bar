package auth

import (
	// externos

	"github.com/gofiber/fiber/v2"
	// locais
)

func Logout(c *fiber.Ctx) error {

	c.Cookie(&fiber.Cookie{
		Name:     "token",
		Value:    "",
		Secure:   true,
		HTTPOnly: true,
	})

	return c.Status(fiber.StatusOK).JSON(fiber.Map{"error": false, "message": "Success."})

}
