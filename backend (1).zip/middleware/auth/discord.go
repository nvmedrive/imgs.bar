package auth

import (
	"github.com/clynt707/discord-oauth2"
	"github.com/gofiber/fiber/v2"
	"golang.org/x/oauth2"

	"os"
)

var state = "random"

func Discord(c *fiber.Ctx) error {

	conf := &oauth2.Config{
		Endpoint:     discord.Endpoint,
		Scopes:       []string{discord.ScopeIdentify, discord.ScopeGuilds, discord.ScopeEmail, discord.ScopeGuildsJoin},
		RedirectURL:  "https://api.imgs.bar/auth/callback",
		ClientID:     os.Getenv("CLIENT_ID"),
		ClientSecret: os.Getenv("CLIENT_SECRET"),
	}

	return c.Redirect(conf.AuthCodeURL(state), fiber.StatusTemporaryRedirect)

}
