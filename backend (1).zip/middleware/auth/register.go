package auth

import (
	"github.com/gofiber/fiber/v2"
	"github.com/upload-wtf/backend/database"
	"github.com/upload-wtf/backend/handler"
)

type Request struct {
	Email         string `json:"email" xml:"email"`
	Password      string `json:"password" xml:"password"`
	Invite        string `json:"invite" xml:"invite"`
	Username      string `json:"username" xml:"username"`
	ResponseToken string `json:"responseToken" xml:"responseToken"`
}

func Register(c *fiber.Ctx) error {
	// we declare the type of the parser
	parser := new(Request)

	// we verify if there are any errors in the request
	if err := c.BodyParser(parser); err != nil {
		return err
	}

	// we verify if the request is empty
	if parser.Email == "" || parser.Password == "" || parser.Invite == "" || parser.Username == "" || parser.ResponseToken == "" {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": true, "message": "Something is missing, try again."})
	}

	token, err := database.Register(parser.Username, parser.Password, parser.Email, parser.Invite)

	if err != nil {
		status, errString := handler.Errors(err)
		return c.Status(status).JSON(fiber.Map{"error": true, "message": errString})
	}

	c.Cookie(&fiber.Cookie{
		Domain:   ".imgs.bar",
		Path:     "/",
		Name:     "token",
		Value:    token,
		Secure:   true,
		HTTPOnly: true,
	})

	return c.Status(fiber.StatusOK).JSON(fiber.Map{"error": false, "message": "user registered"})
}
