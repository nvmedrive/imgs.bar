package utils

import (
	"bytes"
	"image"
	"image/color"
	"image/png"
	"io/ioutil"
	"net/http"

	"github.com/fogleman/gg"
	"github.com/gofiber/fiber/v2"
)

func GenCaptcha(c *fiber.Ctx) error {
	code := c.Query("code")

	img := createImage(code)

	var buf bytes.Buffer
	err := png.Encode(&buf, img)
	if err != nil {
		return c.Status(http.StatusInternalServerError).SendString("Failed to encode CAPTCHA image")
	}

	c.Set(fiber.HeaderContentType, "image/png")

	return c.Send(buf.Bytes())
}

func createImage(code string) image.Image {
	width := 200
	height := 80

	dc := gg.NewContext(width, height)
	dc.SetRGB(1, 1, 1)
	dc.Clear()

	fontColor := color.RGBA{0, 0, 0, 255}
	fontURL := "https://cdn.imgs.bar/files/c84b6b53-e92a-48aa-aff6-4bd1290b5726.ttf"
	fontData, err := downloadFont(fontURL)
	if err != nil {
		// Handle error
	}

	fontPath := "/fonts/font.ttf" // Set the path to save the font file
	err = ioutil.WriteFile(fontPath, fontData, 0644)
	if err != nil {
		// Handle error
	}

	err = dc.LoadFontFace(fontPath, 60)
	if err != nil {
		// Handle error
	}

	dc.SetColor(fontColor)
	dc.DrawStringAnchored(code, float64(width)/2, float64(height)/2, 0.5, 0.5)

	return dc.Image()
}

func downloadFont(fontURL string) ([]byte, error) {
	resp, err := http.Get(fontURL)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	fontData, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return nil, err
	}

	return fontData, nil
}
