package model

import "gorm.io/gorm"

type Logs struct {
	gorm.Model
	UserID int    `gorm:"unique;not null"`
	Date   string `gorm:"not null"`
	Action string `gorm:"not null"`
}
