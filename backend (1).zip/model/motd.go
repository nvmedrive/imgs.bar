package model

import (
	"gorm.io/gorm"
)

type Motd struct {
	gorm.Model
	motd string
}
