package model

import (
	"gorm.io/gorm"
)

type Bio struct {
	gorm.Model
	UserID          int    `gorm:"unique;primarykey"`
	Username        string `gorm:"unique;not null"`
	EmbedDescripton string `gorm:"default:https://imgs.bar"`
	EmbedColor      string `gorm:"default:#000000"`
	LogoUrl         string `gorm:"default:https://imgs.bar/logo.png/"`
	BackgroundUrl   string `gorm:"default:https://cdn.discordapp.com/attachments/919533264119677018/1100115158283583488/20230424_194441_0000.png"`
	Description     string `gorm:"default:imgs.bar on top!!!"`
	Youtube         string `gorm:"default:"`
	Reddit          string `gorm:"default:"`
	Twitch          string `gorm:"default:"`
	Pinterest       string `gorm:"default:"`
	Instagram       string `gorm:"default:"`
	Linkedin        string `gorm:"default:"`
	Github          string `gorm:"default:"`
	Paypal          string `gorm:"default:"`
	DiscordRpc      bool   `gorm:"default:false"`
}

type BioStruct struct {
	UserID          int
	Username        string
	EmbedDescripton string
	EmbedColor      string
	LogoUrl         string
	Description     string
	Youtube         string
	Reddit          string
	Twitch          string
	Pinterest       string
	Linkedin        string
	Github          string
	Paypal          string
	DiscordRpc      bool
}
