package model

import (
	"gorm.io/gorm"
)

type Embeds struct {
	gorm.Model
	UserID      int    `gorm:"unique;primarykey"`
	SiteName    string `gorm:"default:imgs.bar!"`
	SiteNameUrl string `gorm:"default:https://imgs.bar"`
	Title       string `gorm:"default:I am using imgs.bar!"`
	Description string `gorm:"default:imgs.bar is good!"`
	Author      string `gorm:"default:upload-wtf"`
	AuthorUrl   string `gorm:"default:https://imgs.bar"`
	Color       string `gorm:"default:random"`
	Domain      string `gorm:"default:i.imgs.bar"`
	Fakedomain  string `gorm:"default:fbi.gov/at/your/door"`
	Path        string
	Path_Mode   string `gorm:"not null;default:invisible"`
	Path_Amount int    `gorm:"not null;default:5"`
}

type EmbedStruct struct {
	SiteName    string
	SiteNameUrl string
	Title       string
	Description string
	Author      string
	AuthorUrl   string
	Color       string
}
