package model

import "gorm.io/gorm"

type Users struct {
	gorm.Model
	Username      string `gorm:"unique;not null"`
	Email         string `gorm:"unique;not null"`
	Password      string `gorm:"unique;not null"`
	ApiKey        string `gorm:"not null;unique"`
	Token         string `gorm:"not null;unique"`
	Blacklist     string `gorm:"default:null"`
	DiscordID     string `gorm:"default:null"`
	DiscordTAG    string `gorm:"default:null"`
	DiscordAVATAR string `gorm:"default:null"`
	Role          string `gorm:"not null;default:user"`
	InviteBan     bool   `gorm:"not null;default:false"`
	Admin         bool   `gorm:"not null;default:false"`
	Verified      bool   `gorm:"not null;default:false"`

	Show_Uploads       bool `gorm:"default:true;"`
	Show_Discord       bool `gorm:"default:true;"`
	Show_creation_date bool `gorm:"default:true;"`

	Otp_enabled  bool `gorm:"default:false;"`
	Otp_verified bool `gorm:"default:false;"`

	Otp_secret   string
	Otp_auth_url string
}
