package router

import (
	// Middleware

	"github.com/upload-wtf/backend/middleware/admin"
	"github.com/upload-wtf/backend/middleware/auth"
	"github.com/upload-wtf/backend/middleware/bio"
	"github.com/upload-wtf/backend/middleware/bot"
	"github.com/upload-wtf/backend/middleware/files"
	"github.com/upload-wtf/backend/middleware/preferences"
	"github.com/upload-wtf/backend/middleware/profile"
	"github.com/upload-wtf/backend/middleware/stats"
	"github.com/upload-wtf/backend/middleware/status"
	"github.com/upload-wtf/backend/middleware/utils"

	// "github.com/upload-wtf/backend/middleware/domains"

	// Fiber
	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/logger"
)

func ConnectRouter(app *fiber.App) {

	filesRoute := app.Group("/files", logger.New(logger.Config{}))
	// filesRoute := app.Group("/files", logger.New(logger.Config{}), limiterMiddleware)
	authRoute := app.Group("/auth", logger.New(logger.Config{}))
	profileRoute := app.Group("/profile", logger.New(logger.Config{}))
	adminRoute := app.Group("/admin", logger.New(logger.Config{}))
	preferencesRoute := app.Group("/preferences", logger.New(logger.Config{}))
	statusRoute := app.Group("/status", logger.New(logger.Config{}))
	bioRoute := app.Group("/bio", logger.New(logger.Config{}))
	botRoute := app.Group("/bot", logger.New(logger.Config{}))
	// domainRoute := app.Group("/domain", logger.New(logger.Config{}))
	statsRoute := app.Group("/", logger.New(logger.Config{}))
	utilRoute := app.Group("/utils", logger.New(logger.Config{}))

	profile.Routes(profileRoute)
	auth.Routes(authRoute)
	files.Routes(filesRoute)
	admin.Routes(adminRoute)
	preferences.Routes(preferencesRoute)
	status.Routes(statusRoute)
	bio.Routes(bioRoute)
	bot.Routes(botRoute)
	// domain.Routes(domainRoute)
	stats.Routes(statsRoute)
	utils.Routes(utilRoute)
}
