package main

import (
	"encoding/json"
	"fmt"
	"html/template"
	"log"
	"net/http"

	"github.com/gofiber/fiber/v2"
)

// APIResponse is the response returned by the API
type APIResponse struct {
	Data    FileData `json:"data"`
	Error   bool     `json:"error"`
	Message string   `json:"message"`
}

/*
The FileData struct contains the information for a file
that the API returns.
*/
type FileData struct {
	Username    string  `json:"username"`
	UserID      float64 `json:"user_id"`
	FileName    string  `json:"file_name"`
	Title       string  `json:"title"`
	Description string  `json:"description"`
	FileURL     string  `json:"file_url"`
	Author      string  `json:"author"`
	AuthorURL   string  `json:"author_url"`
	SiteName    string  `json:"provider_name"`
	SiteNameURL string  `json:"provider_url"`
	Color       string  `json:"color"`
	MimeType    string  `json:"mime_type"`
}

func main() {
	// Create a new Fiber instance
	app := fiber.New()

	// Fiber route
	app.Get("/:fileID", func(c *fiber.Ctx) error {
		fileID := c.Params("fileID")

		resp, err := http.Get(fmt.Sprintf("https://api.imgs.bar/files/render/%s", fileID))
		if err != nil {
			log.Fatal(err)
		}
		defer resp.Body.Close()

		/*
			This code checks the API response to see if there is a problem.
			If there is a problem, it sets a flag that will be checked later.
			If there is no problem, the flag is not set.
		*/
		var apiResponse APIResponse

		// Error checking
		err = json.NewDecoder(resp.Body).Decode(&apiResponse)
		if err != nil {
			log.Fatal(err)
		}

		// Print the API response
		fmt.Printf("API Response: %+v\n", apiResponse)

		fileData := apiResponse.Data

		if fileData.FileName == "" {
			err404 := `
				<!DOCTYPE html>
				<html>
				<head>
					<title>404 - File not found</title>
				</head>
					<body>
						<h1>404 - File not found</h1>
						<p>The file you are looking for doesn't exist or has been removed.</p>
					</body>
				</html>
			`
			return c.SendString(err404)
		}

		// This code determines the type of file that is being uploaded.
		var MimeType string
		if contains([]string{"image"}, fileData.MimeType) {
			MimeType = "image"
		} else if contains([]string{"video"}, fileData.MimeType) {
			MimeType = "video"
		}

		// fileRendering is a template that defines how the contents of a file should be rendered.
		tmpl := template.Must(template.New("file").Parse(fileRendering))

		// This code is used to convert a file to base64 encoding. The file is then sent as a string to a server for processing.
		data := struct {
			FileData
			MimeType string
		}{fileData, MimeType}

		c.Response().Header.Set("Content-Type", "text/html") // Set the Content-Type to HTML
		err = tmpl.Execute(c.Response().BodyWriter(), data)
		if err != nil {
			log.Fatal(err)
		}

		return nil
	})

	app.Listen(":3000")
}

// contains checks if a string is in a slice of strings
func contains(slice []string, str string) bool {
	for _, s := range slice {
		if s == str {
			return true
		}
	}
	return false
}

// fileRendering is a template that defines how the contents of a file should be rendered.
// fileRendering is a template that defines how the contents of a file should be rendered.
const fileRendering = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <title>{{.Title}}</title>
    <link rel="icon" type="image/png" href="https://imgs.bar/logo.png" />
    <meta property="og:title" content="{{.Title}}">
    <meta property="og:description" content="{{.Description}}">
    <meta name="twitter:title" content="{{.Title}}">
    <meta name="twitter:description" content="{{.Description}}">
    {{if eq .MimeType "[image/png]"}}
    <meta name="twitter:card" content="summary_large_image">
    <meta property="twitter:card" content="https://{{.FileURL}}">
    <meta name="twitter:image" content="https://{{.FileURL}}">
    <meta name="twitter:image:src" content="https://{{.FileURL}}">
    <meta property="og:image" content="https://{{.FileURL}}"> 
    {{end}}
    {{if eq .MimeType "[video/mp4]"}}
    <meta property="twitter:video" content="https://{{.FileURL}}">
    <meta name="twitter:video:src" content="https://{{.FileURL}}">
    <meta property="og:video" content="https://{{.FileURL}}">
    {{end}}
    <link type="application/json+oembed"
        href="https://api.imgs.bar/files/embed?author_name={{.Author}}&author_url={{.AuthorURL}}&provider_name={{.SiteName}}&provider_url={{.SiteNameURL}}">
    <meta name="theme-color" content="{{.Color}}">
    <meta name="robots" content="noindex">
</head>
<body class="bg-[#111112] flex h-screen">
<div class="flex flex-col items-center m-auto">
    <div class="bg-[#1c1c1c] text-center space-y-8 p-10 rounded-xl max-w-sm md:max-w-md 2xl:max-w-2xl">
        <div>
            <h1 class="text-neutral-200 text-3xl">
                {{.FileName}}
            </h1>
            <p class="text-neutral-400 text-sm">Uploaded by {{.Username}} ({{.UserID}})</p>
        </div>
        <a class="flex justify-center mx-auto object-scale-down object-cover hover:scale-150 transition delay-50"
            href="https://{{.FileURL}}">
            {{if eq .MimeType "[image/png]"}}<img class="rounded-2xl" src="https://{{.FileURL}}" alt="{{.FileName}}">{{end}}
            {{if eq .MimeType "[video/mp4]"}}<video class="rounded-lg" src="https://{{.FileURL}}" controls=""></video>{{end}}
        </a>
        <div class="flex flex-row justify-center space-x-2 text-neutral-200 text-base font-medium">
            <a class="rounded bg-red-600 text-sm font-semibold px-5 h-9 text-gray-100 hover:bg-red-700 cursor-pointer flex gap-2 items-center justify-center appearance-none"
                type="button" href="https://imgs.bar/report/">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24"
                    stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round"
                        d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z">
                    </path>
                </svg>
                Report File
            </a>
        </div>
    </div>
</div>
</body>
</html>`
