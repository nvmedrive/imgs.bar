# 🚧 API Routes

## `[GET] /:id`

### Request

```javascript
{
  id: string;
}
```

### Response

- ✅ Status: **200**

```javascript
file
```

- ❌ Status: **500**

```javascript
data: data.error
```
