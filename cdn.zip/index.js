/*
  _                       _                
 (_)                     | |               
  _ _ __ ___   __ _ ___  | |__   __ _ _ __ 
 | | '_ ` _ \ / _` / __| | '_ \ / _` | '__|
 | | | | | | | (_| \__ \_| |_) | (_| | |   
 |_|_| |_| |_|\__, |___(_)_.__/ \__,_|_|   
               __/ |                       
              |___/   
                                   
This file is part of the imgs.bar service
Licensed under the imgs.bar License (see LICENSE)
License: https://imgs.bar/LICENSE
Author: Clynt#6169
*/

var express = require("express");
var app = express();

const createDOMPurify = require('dompurify');
const { JSDOM } = require('jsdom');

const window = new JSDOM('').window;
const DOMPurify = createDOMPurify(window);

require('dotenv').config()

app.listen(process.env.PORT, () => {
    console.log(`Server running on port ${process.env.PORT}`);
});

app.get("/", async (req, res) => {
    res.redirect('https://imgs.bar/');
});

app.get('/:id', async (req, res) => {
    const id = req.params.id;
    const response = await fetch(`https://api.imgs.bar/files/render/${id}`);
    const data = await response.text();
    const json = JSON.parse(data);
    const title = json?.data?.title ?? '';
    const description = json?.data?.description ?? '';
    const author = json?.data?.author ?? '';
    const author_url = json?.data?.author_url ?? '';
    const site_name = json?.data?.provider_name ?? '';
    const site_name_url = json?.data?.provider_url ?? '';
    const file_name = json?.data?.file_name ?? '';
    const file_url = json?.data?.file_url ?? '';
    const color = json?.data?.color ?? '';
    const username = json?.data?.username ?? '';
    const user_id = json?.data?.user_id ?? '';
    const upload_id = json?.data?.upload_id ?? '';
    const mime_type = json?.data?.mime_type ?? '';
    const message = json?.message ?? '';
    
    if (message === "the upload doesn't exist") {
        const err404 = `
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta http-equiv="X-UA-Compatible" content="IE=edge">
                <title>500 - Internal Server Error</title>
                <link rel="icon" type="image/png" href="https://imgs.bar/logo.png" />
                <meta name="theme-color" content="#0f0f0f">
                <script src="https://cdn.tailwindcss.com"></script>
                <meta name="robots" content="noindex">
            </head>
            <body style="background-color:black;">
                <div class="flex h-[calc(100vh-80px)] items-center justify-center p-5 bg-black w-full">
                    <div class="text-center">
                        <div class="inline-flex rounded-full bg-yellow-100 p-4">
                            <div class="rounded-full stroke-yellow-600 bg-yellow-200 p-4">
                                <svg class="w-16 h-16" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M14.0002 9.33337V14M14.0002 18.6667H14.0118M25.6668 14C25.6668 20.4434 20.4435 25.6667 14.0002 25.6667C7.55684 25.6667 2.3335 20.4434 2.3335 14C2.3335 7.55672 7.55684 2.33337 14.0002 2.33337C20.4435 2.33337 25.6668 7.55672 25.6668 14Z" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                </svg>
                            </div>
                        </div>
                        <h1 class="mt-5 text-[36px] font-bold text-white lg:text-[50px]">404 - File not found</h1>
                        <p class="text-white mt-5 lg:text-lg">The file you are looking for doesn't exist or<br />has been removed.</p>
                    </div>
                </div>
            </body>
            </html>
        `;
        res.send(err404);
    }

    let fileType;
    if (mime_type.includes('image')) {
        fileType = 'image';
    } else if (mime_type.includes('video')) {
        fileType = 'video';
    }

    const fileRendering = `
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <script src="https://cdn.tailwindcss.com"></script>
            <title>${DOMPurify.sanitize(file_name)}</title>
            <link rel="icon" type="image/png" href="https://imgs.bar/logo.png" />
            <meta property="og:title" content="${DOMPurify.sanitize(title)}">
            <meta property="og:description" content="${DOMPurify.sanitize(description)}">
            <meta name="twitter:title" content="${DOMPurify.sanitize(title)}">
            <meta name="twitter:description" content="${DOMPurify.sanitize(description)}">
            ${fileType == 'image' ? `
            <meta name="twitter:card" content="summary_large_image">
            <meta property="twitter:card" content="https://${DOMPurify.sanitize(file_url)}">
            <meta name="twitter:image" content="https://${DOMPurify.sanitize(file_url)}">
            <meta name="twitter:image:src" content="https://${DOMPurify.sanitize(file_url)}">
            <meta property="og:image" content="https://${DOMPurify.sanitize(file_url)}"> ` : ''}
            ${fileType == 'video' ? `
            <meta property="twitter:video" content="https://${DOMPurify.sanitize(file_url)}">
            <meta name="twitter:video:src" content="https://${DOMPurify.sanitize(file_url)}">
            <meta property="og:video" content="https://${DOMPurify.sanitize(file_url)}"> ` : ''}
            <link type="application/json+oembed"
                href="https://api.imgs.bar/files/embed?author_name=${DOMPurify.sanitize(author)}&author_url=${DOMPurify.sanitize(author_url)}&provider_name=${DOMPurify.sanitize(site_name)}&provider_url=${DOMPurify.sanitize(site_name_url)}">
            <meta name="theme-color" content="${DOMPurify.sanitize(color)}">
            <meta name="robots" content="noindex">
        </head>
        <body class="bg-[#111112] flex h-screen">
        <div class="flex flex-col items-center m-auto">
            <div class="bg-[#1c1c1c] text-center space-y-8 p-10 rounded-xl max-w-sm md:max-w-md 2xl:max-w-2xl">
                <div>
                    <h1 class="text-neutral-200 text-3xl">
                        ${DOMPurify.sanitize(file_name)}
                    </h1>
                    <p class="text-neutral-400 text-sm">Uploaded by ${DOMPurify.sanitize(username)} (${DOMPurify.sanitize(user_id)})</p>
                </div>
                <a class="flex justify-center mx-auto object-scale-down object-cover hover:scale-150 transition delay-50"
                    href="https://${DOMPurify.sanitize(file_url)} ">
                    ${fileType == 'image' ? ` <img class="rounded-2xl" src="https://${DOMPurify.sanitize(file_url)}" alt="${DOMPurify.sanitize(file_name)}">` : ''}
                    ${fileType == 'video' ? ` <video class="rounded-lg" src="https://${DOMPurify.sanitize(file_url)}" controls=""> </video>` : ''}
                </a>
                <div class="flex flex-row justify-center space-x-2 text-neutral-200 text-base font-medium">
                    <a class="rounded bg-red-600 text-sm font-semibold px-5 h-9 text-gray-100 hover:bg-red-700 cursor-pointer flex gap-2 items-center justify-center appearance-none"
                        type="button" href="https://imgs.bar/report/">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24"
                            stroke="currentColor" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z">
                            </path>
                        </svg>
                        Report File
                    </a>
                </div>
            </div>
        </div>
    </body>
        </html>
    `;
    res.send(fileRendering);
});
